from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import matplotlib as mpl


# Fixed semantics across the paper.  The palette is colour-blind-safe and
# soft but sufficiently saturated for final-size lines and markers. Shapes
# redundantly encode backbone identity for grayscale and colour-vision access.
BLUE = "#4E9BC7"          # EEGNet / non-anticipating access
ORANGE = "#E8895B"        # EEG-Conformer
RED = "#B23A48"           # Oracle, warning, non-deployable boundary
GRAY = "#6B7280"          # Secondary information / transductive access
MID_GRAY = "#9CA3AF"
LIGHT = "#F3F4F6"
GRID = "#D9DEE5"
TEXT = "#20242A"
WHITE = "#FFFFFF"
PALE_BLUE = "#E8F2F8"
PALE_ORANGE = "#FBEDE5"
PALE_RED = "#F7E9EC"
PALE_GRAY = "#F7F8FA"
IVORY = "#FBF8F3"
SAND = "#F3E4C6"
SAGE = "#DDE9DD"
LAVENDER = "#E8E1F0"
BLUSH = "#F3DFE2"
WARM_GRAY = "#E9E4DC"

MODEL_COLORS = {"eegnet": BLUE, "eeg_conformer": ORANGE}
MODEL_LABELS = {"eegnet": "EEGNet", "eeg_conformer": "EEG-Conformer"}
MODEL_MARKERS = {"eegnet": "o", "eeg_conformer": "D"}
PHASE_COLORS = {
    "discovery": SAND,
    "dreyer_confirmation": SAGE,
    "external_confirmation": LAVENDER,
}
ACCESS_FACES = {
    "non_anticipating": PALE_BLUE,
    "strict_past": SAGE,
    "session_forward": LAVENDER,
    "transductive": WARM_GRAY,
    "oracle": BLUSH,
}
ACCESS_HATCHES = {
    "non_anticipating": "",
    "strict_past": "..",
    "session_forward": "\\\\",
    "transductive": "///",
    "oracle": "xx",
}

# Author at final IEEE double-column width so text is not silently reduced.
DOUBLE_COLUMN_WIDTH = 7.16
PNG_DPI = 600
ARTIFACT_DATE = datetime(2026, 8, 29, tzinfo=timezone.utc)

# DejaVu Sans ships with Matplotlib and produces deterministic editable text.
# No figure text is intentionally authored below 7 pt.
FONT_FAMILY = "DejaVu Sans"
PANEL_LABEL_SIZE = 9.0
PANEL_TITLE_SIZE = 8.4
AXIS_LABEL_SIZE = 8.0
TICK_LABEL_SIZE = 7.4
LEGEND_SIZE = 7.2
ANNOTATION_SIZE = 7.3
SMALL_SIZE = 7.0

LINE_WIDTH = 1.25
THIN_LINE_WIDTH = 0.60
MARKER_SIZE = 4.6
CAP_SIZE = 2.2


def apply_publication_style() -> None:
    """Apply the restrained, direct-label visual grammar used by the figures."""
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [FONT_FAMILY, "Arial", "Liberation Sans"],
            "font.size": TICK_LABEL_SIZE,
            "axes.titlesize": PANEL_TITLE_SIZE,
            "axes.titleweight": "semibold",
            "axes.labelsize": AXIS_LABEL_SIZE,
            "axes.labelcolor": TEXT,
            "axes.edgecolor": TEXT,
            "axes.linewidth": THIN_LINE_WIDTH,
            "axes.facecolor": WHITE,
            "axes.axisbelow": True,
            "xtick.labelsize": TICK_LABEL_SIZE,
            "ytick.labelsize": TICK_LABEL_SIZE,
            "xtick.color": TEXT,
            "ytick.color": TEXT,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "xtick.major.size": 2.8,
            "ytick.major.size": 2.8,
            "xtick.major.width": THIN_LINE_WIDTH,
            "ytick.major.width": THIN_LINE_WIDTH,
            "legend.fontsize": LEGEND_SIZE,
            "legend.frameon": False,
            "legend.handlelength": 1.45,
            "legend.handletextpad": 0.35,
            "legend.columnspacing": 0.8,
            "lines.linewidth": LINE_WIDTH,
            "lines.markersize": MARKER_SIZE,
            "grid.color": GRID,
            "grid.linestyle": "-",
            "grid.linewidth": 0.45,
            "grid.alpha": 0.65,
            "hatch.color": MID_GRAY,
            "hatch.linewidth": 0.45,
            "figure.facecolor": WHITE,
            "savefig.facecolor": WHITE,
            "savefig.transparent": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "svg.hashsalt": "tnsre-acdd-editorial-style-v4",
            "mathtext.fontset": "dejavusans",
        }
    )


def save_figure(fig, pdf_path: Path) -> list[Path]:
    """Save one deterministic figure as PDF, editable SVG, and 600-dpi PNG."""
    pdf_path = Path(pdf_path)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    svg_path = pdf_path.with_suffix(".svg")
    png_path = pdf_path.with_suffix(".png")
    common = {"facecolor": WHITE, "edgecolor": "none", "bbox_inches": None, "pad_inches": 0}
    fig.savefig(
        pdf_path,
        format="pdf",
        metadata={
            "Creator": "ACDD TNSRE publication figure system",
            "Title": pdf_path.stem,
            "CreationDate": ARTIFACT_DATE,
            "ModDate": ARTIFACT_DATE,
        },
        **common,
    )
    fig.savefig(
        svg_path,
        format="svg",
        metadata={"Title": pdf_path.stem, "Date": ARTIFACT_DATE.date().isoformat()},
        **common,
    )
    fig.savefig(png_path, format="png", dpi=PNG_DPI, **common)
    return [pdf_path, svg_path, png_path]


apply_publication_style()
