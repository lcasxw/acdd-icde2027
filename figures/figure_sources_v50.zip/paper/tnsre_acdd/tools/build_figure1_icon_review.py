"""Independent Fig. 1 review: shared PDF/SVG/native-Visio vector scene.

No manuscript, active figure, scientific table, or approved v13 file is modified.
Only pictograms are schematic; there are no simulated quantitative plot marks.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor

ROOT = Path(__file__).resolve().parents[3]
PAPER = ROOT / "paper/tnsre_acdd"
OUT = PAPER / "editable_figures/figure1_v15_icon_review"
STEM = "figure1_acdd_workflow_v15_icon_review"
W, H = 482.4, 328.0
INK, MUTED, LINE = "#28323D", "#56616D", "#A8ACB8"
BLUE, GRAY, RED = "#287BA3", "#67717E", "#B65361"
BUTTER, SAGE, LAV = "#F8E8A4", "#DCE9DC", "#E9E3F5"
PALE_BLUE, PALE_GRAY, PALE_RED = "#E8F2F7", "#F0F0ED", "#F9EBEE"

for name, filename in (("Arial", "arial.ttf"), ("Arial-Bold", "arialbd.ttf"),
                       ("Arial-Italic", "ariali.ttf")):
    pdfmetrics.registerFont(TTFont(name, str(Path("C:/Windows/Fonts") / filename)))


class Scene:
    def __init__(self):
        self.items = []
        self.text_boxes = []

    def rect(self, x, y, w, h, fill="none", stroke=LINE, sw=.55, radius=0, dash=False):
        self.items.append(dict(kind="rect", x=x, y=y, w=w, h=h, fill=fill,
                               stroke=stroke, sw=sw, radius=radius, dash=dash))

    def ellipse(self, cx, cy, rx, ry=None, fill="none", stroke=INK, sw=.6):
        self.items.append(dict(kind="ellipse", x=cx-rx, y=cy-(ry or rx), w=rx*2,
                               h=(ry or rx)*2, fill=fill, stroke=stroke, sw=sw))

    def line(self, pts, color=INK, sw=.65, arrow=False, dash=False):
        self.items.append(dict(kind="line", pts=pts, stroke=color, sw=sw, dash=dash, arrow=arrow))
        if arrow:
            (x0, y0), (x1, y1) = pts[-2:]
            a = math.atan2(y1-y0, x1-x0)
            size = 3.3
            self.items.append(dict(kind="polygon", pts=[(x1, y1),
                (x1-size*math.cos(a)+1.45*math.sin(a), y1-size*math.sin(a)-1.45*math.cos(a)),
                (x1-size*math.cos(a)-1.45*math.sin(a), y1-size*math.sin(a)+1.45*math.cos(a))],
                fill=color, stroke=color, sw=.25, arrowhead=True))

    def text(self, x, y, value, size=7.2, color=INK, bold=False, align="left", italic=False):
        font = "Arial-Bold" if bold else "Arial-Italic" if italic else "Arial"
        width = pdfmetrics.stringWidth(value, font, size)
        xx = x - (width/2 if align == "center" else width if align == "right" else 0)
        self.items.append(dict(kind="text", x=x, y=y, text=value, size=size, color=color,
                               bold=bold, italic=italic, align=align, font=font))
        self.text_boxes.append(dict(text=value, x=xx, y=y-size*.9, w=width,
                                    h=size*1.15, size=size))
        return width

    def math(self, x, y, runs, size=10.5):
        """Separate editable text runs; subscripts have an actual lower baseline."""
        for word, sub, color in runs:
            ss = 7.0 if sub else size
            x += self.text(x, y+2.1 if sub else y, word, ss, color,
                           italic=(not sub and word.strip() in ("G", "L")))
        return x

    def panel(self, x, y, w, h, number, title, accent):
        self.rect(x, y, w, h, "#FFFFFF", accent, .65, 4, True)
        self.rect(x+7, y+6, 14, 13, accent, "none", radius=3)
        self.text(x+14, y+15.4, number, 8, "#FFFFFF", True, "center")
        self.text(x+26, y+15.3, title, 8.5, INK, True)

    def export(self):
        OUT.mkdir(parents=True, exist_ok=True)
        c = canvas.Canvas(str(OUT / (STEM + ".pdf")), pagesize=(W, H), invariant=1,
                          pageCompression=1)
        c.setAuthor("")
        c.setCreator("Vector figure builder")
        c.setTitle("ACDD workflow - independent icon-enhanced review")
        c.setSubject("Review draft; not synchronized to the manuscript")
        svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="6.7in" height="{H/72:.9f}in" viewBox="0 0 {W} {H}">',
               '<title>ACDD workflow: independent icon-enhanced review</title>',
               '<desc>Editable vector schematic. Pictograms are conceptual, not measured data.</desc>']
        native_shapes, native_lines = [], []

        def native_shape(kind, x, y, w, h, style, text="", radius=0):
            ident = f"shape{len(native_shapes):04d}"
            item = dict(id=ident, type=kind, x=x/72, y=y/72, w=w/72, h=h/72,
                        text=text, style_override=style)
            if radius:
                item["corner_radius"] = radius/72
            native_shapes.append(item)
            return ident

        for item in self.items:
            k = item["kind"]
            if k == "text":
                x, y, val, ss = item["x"], item["y"], item["text"], item["size"]
                c.setFont(item["font"], ss)
                c.setFillColor(HexColor(item["color"]))
                fn = c.drawCentredString if item["align"] == "center" else c.drawRightString if item["align"] == "right" else c.drawString
                fn(x, H-y, val)
                anchor = {"left":"start", "center":"middle", "right":"end"}[item["align"]]
                weight = "700" if item["bold"] else "400"
                italic = "italic" if item["italic"] else "normal"
                svg.append(f'<text x="{x}" y="{y}" font-family="Arial" font-size="{ss}" font-weight="{weight}" font-style="{italic}" text-anchor="{anchor}" fill="{item["color"]}">{escape(val)}</text>')
                tw = pdfmetrics.stringWidth(val, item["font"], ss) + 1.2
                nx = x-(tw/2 if item["align"] == "center" else tw if item["align"] == "right" else .6)
                # Visio uses its own glyph metrics. An exact-width + 1.2 pt text box
                # is vertically centred on the Arial cap/descender envelope.
                native_shape("text", nx, y-ss*.92, tw, ss*1.2,
                             dict(fill="none", stroke="none", font_family="Arial", font_size_pt=ss,
                                  font_color=item["color"], font_bold=item["bold"], font_italic=item["italic"],
                                  align=item["align"], valign="middle", padding=0), val)
                continue
            stroke, fill, sw = item["stroke"], item.get("fill", "none"), item["sw"]
            c.setLineWidth(sw)
            c.setLineCap(1)
            c.setLineJoin(1)
            c.setDash([3.2, 2.5] if item.get("dash") else [])
            if stroke != "none": c.setStrokeColor(HexColor(stroke))
            if fill != "none": c.setFillColor(HexColor(fill))
            attrs = f'fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"'
            if item.get("dash"): attrs += ' stroke-dasharray="3.2 2.5"'
            style = dict(fill=fill, stroke=stroke, stroke_width_pt=sw,
                         stroke_dash="dash" if item.get("dash") else "solid")
            if k in ("rect", "ellipse"):
                x, y, w, h = (item[t] for t in ("x", "y", "w", "h"))
                if k == "rect":
                    rr = item["radius"]
                    c.roundRect(x, H-y-h, w, h, rr, stroke=int(stroke!="none"), fill=int(fill!="none"))
                    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rr}" {attrs}/>')
                    native_shape("roundrect" if rr else "rect", x, y, w, h, style, radius=rr)
                else:
                    c.ellipse(x, H-y-h, x+w, H-y, stroke=int(stroke!="none"), fill=int(fill!="none"))
                    svg.append(f'<ellipse cx="{x+w/2}" cy="{y+h/2}" rx="{w/2}" ry="{h/2}" {attrs}/>')
                    native_shape("ellipse", x, y, w, h, style)
                continue
            pts = item["pts"]
            pp = c.beginPath()
            pp.moveTo(pts[0][0], H-pts[0][1])
            for px, py in pts[1:]: pp.lineTo(px, H-py)
            if k == "polygon": pp.close()
            c.drawPath(pp, stroke=1, fill=int(k=="polygon"))
            coords = " ".join(f"{x},{y}" for x,y in pts)
            svg.append(f'<{"polygon" if k=="polygon" else "polyline"} points="{coords}" {attrs}/>')
            # Use actual filled native connector arrowheads in the workbench.
            # SVG/PDF triangles above preserve the exact authored arrow shape.
            if item.get("arrowhead"):
                continue
            pairs = list(zip(pts, pts[1:]))
            if k == "polygon": pairs.append((pts[-1], pts[0]))
            # Fill the tiny backbone diamond with short native line spans.
            # Native specs deliberately have no arbitrary polygon operation.
            if k == "polygon" and fill != "none":
                low, high = min(y for x,y in pts), max(y for x,y in pts)
                scan = low + .075
                while scan < high:
                    crosses=[]
                    for aa,bb in list(zip(pts,pts[1:]+pts[:1])):
                        if min(aa[1],bb[1]) <= scan < max(aa[1],bb[1]):
                            crosses.append(aa[0]+(scan-aa[1])*(bb[0]-aa[0])/(bb[1]-aa[1]))
                    crosses.sort()
                    for first,last in zip(crosses[::2],crosses[1::2]):
                        pairs.append(((first,scan),(last,scan)))
                    scan += .15
            for seg, (aa, bb) in enumerate(pairs):
                anchors=[]
                for xx, yy in (aa, bb):
                    anchors.append(native_shape("rect", xx-.015, yy-.015, .03, .03,
                                                dict(fill="none", stroke="none")))
                line_style = dict(style)
                if item.get("arrow") and seg == len(pairs)-1:
                    line_style["arrow_end"] = "triangle"
                native_lines.append(dict(id=f"line{len(native_lines):04d}",
                                         **{"from":dict(shape=anchors[0], port="center"),
                                            "to":dict(shape=anchors[1], port="center")},
                                         routing="straight", text="", style_override=line_style))
        c.showPage()
        c.save()
        svg.append("</svg>")
        (OUT/(STEM+".svg")).write_text("\n".join(svg), encoding="utf-8")
        spec = dict(schema="codex-visio-native/v1", units="in", defaults=dict(padding=0),
                    styles={}, pages=[dict(id="review", name="Fig1 icon-enhanced review", width=W/72,
                        height=H/72, shapes=native_shapes, connectors=native_lines)])
        (OUT/(STEM+"_native_spec.json")).write_text(json.dumps(spec, indent=2), encoding="utf-8")
        return spec


def lock(s, x, y, color=MUTED, scale=1):
    s.ellipse(x+4*scale, y+3*scale, 3*scale, 3.8*scale, stroke=color, sw=.7)
    s.rect(x, y+3*scale, 8*scale, 6.4*scale, "#FFFFFF", color, .7, 1)
    s.ellipse(x+4*scale, y+6*scale, .75*scale, fill=color, stroke="none")


def archive(s, x, y):
    for dx,dy in ((0,0),(2,2),(4,4)):
        s.rect(x+dx, y+dy, 8, 6, "#FFFFFF", "#8E814B", .6, 1)


def shield(s, x, y):
    s.line([(x,y),(x+9,y),(x+9,y+6),(x+4.5,y+10),(x,y+6),(x,y)], "#8371A5", .7)
    s.line([(x+2,y+4),(x+4,y+6),(x+7,y+2.5)], "#8371A5", .8)


def person(s, x, y, color=GRAY, scale=1):
    s.ellipse(x, y, 2.6*scale, fill="#FFFFFF", stroke=color, sw=.65)
    s.line([(x,y+2.6*scale),(x,y+11*scale)], color, .7)
    s.line([(x-4.7*scale,y+6.4*scale),(x+4.7*scale,y+6.4*scale)], color, .7)


def eeg_cap_and_traces(s):
    """Eight neutral contacts; positions and short traces are schematic."""
    s.ellipse(40,151.5,9,9,fill="#FFFFFF",stroke=MUTED,sw=.65)
    s.line([(37.9,142.7),(40,140.4),(42.1,142.7)],MUTED,.6)
    s.line([(30.9,148.2),(29.6,149.2),(29.6,153.8),(30.9,154.8)],MUTED,.6)
    s.line([(49.1,148.2),(50.4,149.2),(50.4,153.8),(49.1,154.8)],MUTED,.6)
    contacts=[(36,147.2),(44,147.2),(34.6,151.5),(40,151.5),(45.4,151.5),
              (35.7,155.7),(40,156.3),(44.3,155.7)]
    for xx,yy in contacts:
        s.ellipse(xx,yy,1.0,fill="#A9CDDC",stroke=BLUE,sw=.4)
    # No axes, amplitudes, or empirical signal measurements are claimed.
    traces=[[(21,165),(26,165),(29,163.5),(32,166.2),(35,161.9),(38,166),(42,164),(46,165),(59,165)],
            [(21,170),(27,170),(31,171.1),(35,168.1),(39,172),(43,167.7),(46,170),(59,170)],
            [(21,175),(25,175),(30,173.7),(34,176.1),(39,174.4),(44,176),(48,174.2),(52,175),(59,175)]]
    for pts,col in zip(traces,(BLUE,"#7196AA","#8AACA9")):
        s.line(pts,col,.5)


def backbone_icon(s, x, y, conformer=False):
    """Abstract processing glyphs, not a literal architecture diagram."""
    green="#749279"
    if not conformer:
        for dx,dy,fill in ((0,0,"#EEF3EC"),(3,2,"#DCE8D8"),(6,4,"#BCD2BC")):
            s.rect(x+dx,y+dy,12,10,fill,green,.4,.6)
        # Equal grid cells indicate feature maps, not quantitative activations.
        for xx in (x+10,x+14): s.line([(xx,y+4),(xx,y+14)],"#94B097",.3)
        s.line([(x+6,y+9),(x+18,y+9)],"#94B097",.3)
        s.rect(x+7,y+5,3,3,"#F4F7EF",green,.35)
    else:
        s.rect(x,y+3,6,8,"#E8EFE2",green,.4,.6)
        s.rect(x+2,y+5,6,8,"#BCD2BC",green,.4,.6)
        s.line([(x+8,y+9),(x+10,y+9)],green,.5)
        for j,fill in enumerate(("#D8D0F0","#BFCFC0","#D7DDE8")):
            s.rect(x+11+j*3.8,y+5,2.7,8,fill,"#8D86A4",.35,.4)
        s.line([(x+12.3,y+4),(x+12.3,y+1.5),(x+19.9,y+1.5),(x+19.9,y+4)],"#8D86A4",.45)
        s.line([(x+16.1,y+1.5),(x+16.1,y+4)],"#8D86A4",.45)


def tag_outline(s, x, y, color, scale=1):
    pts=[(0,0),(8,0),(11,4),(8,8),(0,8),(0,0)]
    s.line([(x+xx*scale,y+yy*scale) for xx,yy in pts],color,.6)
    s.ellipse(x+7.5*scale,y+4*scale,.75*scale,fill="#FFFFFF",stroke=color,sw=.4)


def access_icon(s, x, y, mode, color):
    """Fit-permission icons; no decorative data, clocks, or winner badges."""
    if mode=="solid":
        tag_outline(s,x+1,y+1,color,1.15)
        s.line([(x,y+.1),(x+14,y+11.3)],color,.85)
    elif mode=="hatch":
        for dx,dy in ((0,0),(2,2),(4,4)):
            s.rect(x+dx,y+dy,10,7,"#FFFFFF",color,.55,.7)
        for yy in (y+6.2,y+8.7): s.line([(x+6,yy),(x+11.8,yy)],color,.45)
    else:
        s.rect(x,y,7,10,"#FFFFFF",color,.55,.6)
        for yy in (y+3,y+5.6): s.line([(x+1.5,yy),(x+5.5,yy)],color,.4)
        tag_outline(s,x+6.7,y+5,color,.76)


def build():
    protected = [PAPER/"main.pdf",PAPER/"main.tex",PAPER/"supplementary.pdf",PAPER/"supplementary.tex",
                 PAPER/"claim_registry.json",PAPER/"source_data_contract.json",PAPER/"submission_checks.md",
                 PAPER/"editable_figures/figure1_acdd_workflow_visio_refined_v13.vsdx",
                 Path(__file__).with_name("build_figure1_reference_review.py")]
    protected += [p for p in (PAPER/"figures").iterdir() if p.suffix in (".pdf",".svg",".png")]
    protected += list((PAPER/"source_data").glob("*.csv"))
    protected += [p for p in (PAPER/"editable_figures/figure1_v14_reference_review").iterdir() if p.is_file()]
    hash_file=lambda pp: hashlib.sha256(pp.read_bytes()).hexdigest()
    before={str(p.relative_to(PAPER)):hash_file(p) for p in protected if p.exists()}
    rows = list(csv.DictReader((PAPER/"source_data/figure1_workflow.csv").open(encoding="utf-8-sig")))
    by_id = {row["node_id"]:row for row in rows}
    n_discovery = by_id["historical_discovery"]["n_participants"]
    n_locked = by_id["locked_confirmation"]["n_participants"]
    n_protected = by_id["protected_external_test"]["n_participants"]
    registered = by_id["protected_external_test"]["inference_units"]
    s = Scene()
    s.rect(0, 0, W, H, "#FFFFFF", "none")
    s.text(5, 16, "Access-conditioned deployment audit", 12, INK, True)
    s.text(W-5, 15.5, "Frozen decoders · matched access", 7.2, MUTED, align="right")
    s.panel(4,28,322,288,"a","Main audit framework","#9A939C")

    # An evidence register, deliberately not connected to the new raw-logit path.
    for x, heading, fill, count, note, icon in (
        (13,"Discovery", "#FCF5D8",f"4 cohorts · n={n_discovery}","Probability-only exports",archive),
        (117,"Locked", "#EAF1E8",f"Dreyer · n={n_locked}","Prespecified test",lock),
        (221,"Protected", "#F0EBF8",f"Stieger · n={n_protected}",f"{registered} registered units",shield)):
        s.rect(x,54,96,47,fill,"none",radius=3)
        icon(s,x+10,61)
        s.text(x+29,68,heading,8,INK,True)
        s.text(x+48,82,count,7.4,INK,align="center")
        s.text(x+48,94,note,7,MUTED,align="center")
    s.line([(13,107),(317,107)], "#DFE1E6", .5)
    s.text(14,118,"Frozen target inference",7.8,INK,True)
    s.text(315,118,"Protected raw-BN",7.1,MUTED,align="right")

    s.rect(14,127,52,53,"#F7FAFB","#C2CDD6",.55,3)
    s.text(40,137,"Target EEG",7.4,INK,True,"center")
    eeg_cap_and_traces(s)
    # Explicit fork into parallel alternatives, never a serial model stack.
    s.line([(66,153.5),(79,153.5),(79,137),(94,137)],MUTED,.7,True)
    s.line([(79,153.5),(79,169),(94,169)],MUTED,.7,True)
    s.ellipse(79,153.5,1.4,fill=MUTED,stroke="none")
    for yy,name,col,glyph in ((126,"EEGNet",BLUE,"circle"),(158,"EEG-Conformer","#CE914F","diamond")):
        s.rect(94,yy,111,22,"#F4F8F2","#9BB79E",.6,3)
        backbone_icon(s,99,yy+3,conformer=(glyph=="diamond"))
        if glyph=="circle": s.ellipse(129,yy+11,2.1,fill=col,stroke="none")
        else:
            s.items.append(dict(kind="polygon",pts=[(129,yy+8.4),(131.6,yy+11),(129,yy+13.6),(126.4,yy+11)],fill=col,stroke=col,sw=.2))
        s.text(135,yy+13.8,name,7.6,INK,True)
        s.line([(205,yy+11),(226,yy+11)],col,.75,True)
        for j,fill in enumerate(("#D8E8ED","#C6DAE4","#ABC9D6","#DFEAF0")):
            s.rect(226+j*6.2,yy+6,4.7,10,fill,"#7D9BAA",.35)
        s.line([(250,yy+11),(263,yy+11)],col,.65,True)
    s.text(239,124,"Scores",7,MUTED,align="center")
    # A repeat-operation box, not a numerical merge/ensemble junction.
    s.rect(263,126,54,54,"#FAFBFC","#BDC8D0",.5,3)
    s.text(290,146,"Repeat audit",7.2,INK,align="center")
    s.text(290,158,"per backbone",7.2,INK,align="center")
    lock(s,54,185,BLUE,.8)
    s.text(68,192,"Frozen weights · no retraining / reselection",7.2,MUTED)
    s.line([(290,180),(290,201),(61,201)],MUTED,.65)
    for cx,col in ((61,BLUE),(165,GRAY),(269,RED)):
        s.ellipse(cx,201,1.3,fill=col,stroke="none")
        s.line([(cx,201),(cx,209)],col,.75,True)

    cards = [(13,BLUE,PALE_BLUE,"Non-anticipating",["No target labels in fit","Source-only · prefix → suffix","Strict-past · session-forward"],"solid"),
             (117,GRAY,PALE_GRAY,"Complete batch",["All target scores","Transductive upper bound","Not online"],"hatch"),
             (221,RED,PALE_RED,"Label-informed",["Target scores + labels","Oracle threshold","Diagnostic, not deployable"],"cross")]
    for x,col,fill,title,body,pattern in cards:
        s.rect(x,210,96,61,fill,col,.7,3)
        access_icon(s,x+7,215,pattern,col)
        s.text(x+59,222,title,7.6,col,True,"center")
        s.line([(x+9,228),(x+87,228)],col,.35)
        for j,txt in enumerate(body): s.text(x+48,239+11*j,txt,7,INK,align="center")
        s.line([(x+48,271),(x+48,281)],col,.65,True)
        s.rect(x,282,96,15,"#FFFFFF",col,.5,2)
        s.text(x+48,292.3,"Within-contract audit",7.3,col,True,"center")
    s.text(165,309,"Protected prefix result: MIXED · below the 2-pp gate",7.2,RED,True,"center")

    # (b) a strict prefix / suffix contract, not invented probability density.
    s.panel(334,28,144.4,89,"b","Protected time contract","#7E9B86")
    s.text(345,56,f"Stieger · raw-BN · n={n_protected}",7.2,MUTED)
    x0,yy,step=345,65,5.7
    for j in range(10): s.rect(x0+j*step,yy,4.3,11,"#B8D6E4",BLUE,.4)
    for j in range(10,18): s.rect(x0+j*step,yy,4.3,11,"#D4E4CE","#749575",.4)
    s.text(453,74,"...",7.2,"#527757")
    s.rect(459,yy,4.3,11,"#D4E4CE","#749575",.4)
    cut=x0+10*step-1
    s.line([(cut,61),(cut,81)],MUTED,.55,dash=True)
    s.line([(345,80),(398,80)],BLUE,.65)
    s.line([(403,80),(463,80)],"#749575",.65)
    s.text(371.5,91,"Fit: first 10",7.3,BLUE,True,"center")
    s.text(435,91,"Test: suffix",7.3,"#527757",True,"center")
    s.text(345,104,"Unlabeled fit; labels only for evaluation",7,MUTED)

    # (c) three semantic math components, true subscripts, signed residual.
    s.panel(334,125,144.4,89,"c","Decision decomposition","#9585B4")
    s.rect(344,147,124.4,22,"#F4F1F8","none",radius=3)
    s.math(351,162,[("G",False,BLUE),("A",True,BLUE),(" = ",False,INK),
                         ("L",False,"#547C59"),("decision",True,"#547C59"),
                         (" − ",False,INK),("L",False,"#82709F"),("A",True,"#82709F")],11.2)
    s.math(345,178,[("G",False,BLUE),("A",True,BLUE),(": BA gain over default",False,INK)],7.2)
    s.math(345,189,[("L",False,"#547C59"),("decision",True,"#547C59"),(": default decision loss",False,INK)],7.2)
    s.math(345,200,[("L",False,"#82709F"),("A",True,"#82709F"),(": signed residual to oracle",False,INK)],7.2)
    s.text(345,210,"Same trials · label-informed oracle",7,MUTED)

    # (d) real replication factors; pictograms are not quantitative observations.
    s.panel(334,222,144.4,94,"d","Participant aggregation","#89929F")
    s.text(406.2,247,"Within each backbone",7,MUTED,align="center")
    for row in range(5):
        for col in range(3):
            s.rect(347+col*6.6,255+row*4.2,5.1,3.3,
                   ["#C4D9E4","#D8D0F0","#CCE0CD"][col],"#91A2AC",.25)
    s.line([(369,266),(392,266)],MUTED,.65,True)
    person(s,402,259,GRAY,1.1)
    s.line([(410,266),(432,266)],MUTED,.65,True)
    for px,py in ((442,258),(452,255),(462,258)): person(s,px,py,GRAY,.65)
    s.text(356,284,"5 conditions",7.1,INK,align="center")
    s.text(356,294,"× 3 seeds",7.1,INK,align="center")
    s.text(402,284,"Participant",7.0,INK,align="center")
    s.text(402,294,"mean",7.0,INK,align="center")
    s.text(452,284,f"{n_protected} participants",7.0,INK,align="center")
    s.text(452,294,"Summary",7.0,INK,align="center")
    s.text(406.2,308,"Raw-BN: 30 of 90 registered units",7,MUTED,align="center")
    s.text(5,325,"Model, signal and permission glyphs are schematic.",7,MUTED)

    spec=s.export()
    source_files = ["source_data/figure1_workflow.csv","claim_registry.json","source_data_contract.json","main.tex","frozen_decoder_specification.json"]
    after={name:hash_file(PAPER/name) for name in before}
    assert before==after, "A protected input changed during the review build"
    qa = dict(status="render_and_visio_review_pending", width_inches=W/72,height_inches=H/72,
              minimum_font_pt=min(t["size"] for t in s.text_boxes),
              native_shapes=len(spec["pages"][0]["shapes"]),native_connectors=len(spec["pages"][0]["connectors"]),
              text_count=len(s.text_boxes),text_boxes=s.text_boxes,
              source_sha256={name:hash_file(PAPER/name) for name in source_files},
              preserved_sha256=before, preserved_file_count=len(before),
              scope="Independent v15 review only; no manuscript or approved v13 replacement",
              statistical_notes=["No synthetic data generated; all waveforms and glyphs are schematic.",
                "Counts read from figure1_workflow.csv. Source-seed factors and raw-BN subset from main.tex.",
                "G_A=L_decision-L_A; all terms use identical evaluation trials; residual is signed.",
                "Target labels absent from deployable fitting, not from final evaluation.",
                "Access conditions audited separately; full batch is transductive and oracle diagnostic.",
                "Eight neutral electrode dots reflect input-channel count, not measured coordinates or scalp topography.",
                "CNN feature-map and Conformer convolution/token glyph counts do not encode layer/head counts.",
                "Permission pictograms replace generic textures and do not imply method quality or online availability."])
    (OUT/(STEM+"_qa.json")).write_text(json.dumps(qa,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in qa.items() if k not in ("text_boxes",)},indent=2))


if __name__=="__main__":
    build()
