"""Two single-column radar panels from frozen, seed-resolved omission gains."""
from __future__ import annotations

import csv
import math
import os
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.legend_handler import HandlerTuple
from matplotlib.patches import Polygon

from plot_style import GRAY, GRID, MODEL_COLORS, MODEL_LABELS, TEXT, WHITE
from radar_seed_data import BACKBONES, OMISSION_ORDER, RADIAL_LIMITS_PP, SEEDS

LABELS = ("BNCI2014-001", "Cho2017", "Lee2019-MI", "PhysioNetMI", "LODO")
SEED_STYLES = {
    17: {"color": "#9298A1", "linestyle": "-", "marker": "o"},
    29: {"color": "#9298A1", "linestyle": (0, (4, 2)), "marker": "s"},
    43: {"color": "#9298A1", "linestyle": (0, (1, 1.6)), "marker": "^"},
}
MIN_PP, MAX_PP = RADIAL_LIMITS_PP
ANGLES = [math.pi / 2 - index * 2 * math.pi / 5 for index in range(5)]
DIRECTIONS = [(math.cos(angle), math.sin(angle)) for angle in ANGLES]


def _read_inputs(source: Path):
    directory = Path(os.environ.get(
        "ACDD_RADAR_DATA_DIR", str(Path(source).parent / "plot_data" / "figure4_seed_radar"),
    ))
    def rows(path):
        with path.open(encoding="utf-8-sig", newline="") as stream:
            return list(csv.DictReader(stream))

    frozen = rows(Path(source) / "figure5_leave_one_protocol_out.csv")
    copied = rows(directory / "frozen_mean_summary.csv")
    seeds = rows(directory / "seed_summary.csv")
    expected = {(b, p) for b in BACKBONES for p in OMISSION_ORDER}
    means = {(row["backbone"], row["omitted_protocol"]): row for row in frozen}
    copied_means = {(row["backbone"], row["omitted_protocol"]): row for row in copied}
    seed_values = {(row["backbone"], row["omitted_protocol"], int(row["seed"])): row for row in seeds}
    if len(frozen) != 10 or len(copied) != 10 or set(means) != expected or set(copied_means) != expected:
        raise ValueError("Figure 4 requires all ten frozen omission means")
    if len(seeds) != 30 or set(seed_values) != {(b, p, s) for b, p in expected for s in SEEDS}:
        raise ValueError("Figure 4 requires all 30 seed/omission means")
    for key, row in copied_means.items():
        if row["mean_gain"] != means[key]["mean_gain"]:
            raise ValueError(f"Frozen mean changed: {key}")
        if abs(sum(float(seed_values[(*key, s)]["mean_gain"]) for s in SEEDS) / 3 - float(row["mean_gain"])) > 1e-12:
            raise ValueError(f"Seed means do not reconstruct frozen mean: {key}")
    for row in [*copied, *seeds]:
        if (row["candidate"] != "raw-bn" or row["method"] != "target_prior_quantile"
                or row["endpoint"] != "prefix_suffix" or row["analysis_variant"] != "main"
                or int(row["n_participants"]) != 62 or int(row["n_protocols_kept"]) != 4):
            raise ValueError("Figure 4 input violates the protected data contract")
        gain = float(row["mean_gain_pp"])
        if not math.isfinite(gain) or not MIN_PP <= gain <= MAX_PP:
            raise ValueError("A gain is outside the common signed scale")
        if abs(gain - 100 * float(row["mean_gain"])) > 1e-12:
            raise ValueError("Figure 4 percentage-point conversion mismatch")
    return copied_means, seed_values


def _vertices(gains):
    # A signed, linear scale with its origin explicitly set to -1 pp. Never pass
    # negative radii to polar axes: doing so flips rather than displays a value.
    return [((gain - MIN_PP) * dx, (gain - MIN_PP) * dy)
            for gain, (dx, dy) in zip(gains, DIRECTIONS)]


def _contour(ax, gains, **style):
    vertices = _vertices(gains)
    closed = vertices + vertices[:1]
    return ax.plot([p[0] for p in closed], [p[1] for p in closed], **style)[0]


def build_radar_figure(source: Path) -> Figure:
    means, seeds = _read_inputs(source)
    fig = plt.figure(figsize=(3.25, 5.3), facecolor=WHITE)
    fig.text(.5, .994, "Target: Stieger2021 · n = 62",
             ha="center", va="top", fontsize=8.5, color=TEXT)
    fig.text(.5, .965, "Axes: condition omitted from aggregation",
             ha="center", va="top", fontsize=7.5, color=GRAY)
    # Identical panel geometry; labels remain fully inside the PDF page.
    for index, backbone in enumerate(BACKBONES):
        bottom = .535 if index == 0 else .12
        ax = fig.add_axes([.015, bottom, .97, .365])
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlim(-8.5, 8.5)
        ax.set_ylim(-6.5, 7.6)
        ax.set_axis_off()
        color = MODEL_COLORS[backbone]
        title_offset = .393 if index == 0 else .406
        fig.text(.055, bottom + title_offset, f"({'ab'[index]})",
                 ha="left", va="top", fontsize=8.5, fontweight="semibold", color=TEXT)
        fig.text(.137, bottom + title_offset, MODEL_LABELS[backbone],
                 ha="left", va="top", fontsize=8.5, fontweight="semibold", color=color)

        # The fill belongs only to the negative reference region, never to a
        # data contour. It makes the shifted origin visible at column width.
        ax.add_patch(Polygon(_vertices([0] * 5), closed=True,
                             facecolor="#ECEFF2", edgecolor="none", zorder=0,
                             gid=f"{backbone}-negative-reference-region"))
        for gain in (0, 1, 2, 3, 4, 5):
            zero = gain == 0
            ax.add_patch(Polygon(_vertices([gain] * 5), closed=True, fill=False,
                                 edgecolor="#56616E" if zero else GRID,
                                 linewidth=.85 if zero else .40,
                                 zorder=1 if zero else 0,
                                 gid=f"{backbone}-grid-{gain}pp"))
        for dx, dy in DIRECTIONS:
            ax.plot([0, (MAX_PP - MIN_PP) * dx], [0, (MAX_PP - MIN_PP) * dy],
                    color=GRID, linewidth=.45, zorder=0)
        # Sparse ticks follow the upper spoke; no number ladder crosses the
        # lower data profiles. All six grid rings retain one-pp spacing.
        ax.text(0, -.12, "−1", ha="center", va="center", fontsize=7.5,
                color=GRAY, zorder=6)
        for gain in (0, 2, 4, 5):
            ax.text(.53, gain - MIN_PP, str(gain), ha="left", va="center", fontsize=7.5,
                    color="#56616E" if gain == 0 else GRAY,
                    bbox={"facecolor": WHITE, "edgecolor": "none", "pad": .08}, zorder=6)

        for seed in SEEDS:
            gains = [float(seeds[(backbone, omitted, seed)]["mean_gain_pp"]) for omitted in OMISSION_ORDER]
            _contour(ax, gains, **SEED_STYLES[seed], linewidth=.75, markersize=3.2,
                     markerfacecolor=WHITE, markeredgewidth=.65,
                     gid=f"{backbone}-seed-{seed}", zorder=2)
        mean_gains = [float(means[(backbone, omitted)]["mean_gain_pp"]) for omitted in OMISSION_ORDER]
        _contour(ax, mean_gains, color=color, linewidth=1.75, marker="D" if index else "o",
                 markersize=3.6, markerfacecolor=WHITE, markeredgewidth=1.1,
                 gid=f"{backbone}-frozen-mean", zorder=4)

        # Outside labels carry only frozen means. Full-precision seed values
        # remain in the companion CSV; both negative values are in the caption.
        anchors = [(0, 7.62), (6.55, 2.75), (4.35, -5.50), (-4.35, -5.50), (-6.55, 2.75)]
        for label, gain, (x, y) in zip(LABELS, mean_gains, anchors):
            ax.text(x, y, label, ha="center", va="center", fontsize=7.5, color=TEXT, zorder=7)
            ax.text(x, y - .76, f"μ = {gain:.2f}", ha="center", va="center", fontsize=7.5,
                    fontweight="semibold", color=color, zorder=7)

    handles = [Line2D([0], [0], **SEED_STYLES[s], linewidth=.8,
                      markersize=3.2, markerfacecolor=WHITE, markeredgewidth=.65,
                      label=f"Seed {s}") for s in SEEDS]
    mean_handles = tuple(Line2D([0], [0], color=MODEL_COLORS[b], linewidth=1.75,
                               marker="o" if i == 0 else "D", markersize=3.6,
                               markerfacecolor=WHITE, markeredgewidth=1.1)
                         for i, b in enumerate(BACKBONES))
    fig.legend([mean_handles], ["Mean across seeds (μ)"],
               handler_map={tuple: HandlerTuple(ndivide=None, pad=.5)},
               loc="center", bbox_to_anchor=(.5, .093), frameon=False,
               fontsize=7.5, handlelength=3.2, handletextpad=.6, labelcolor=TEXT)
    # Center the two legend rows and the unit note on one vertical axis,
    # with an equal baseline rhythm and equal gaps between the seed keys.
    fig.legend(handles=handles, loc="center", bbox_to_anchor=(.5, .058), ncol=3,
               frameon=False, fontsize=7.5, handlelength=1.8, handletextpad=.45,
               columnspacing=1.15, labelcolor=TEXT)
    fig.text(.5, .023, "BA gain (pp) · shaded center: negative gain",
             ha="center", va="center", fontsize=7.5, color=GRAY)
    return fig
