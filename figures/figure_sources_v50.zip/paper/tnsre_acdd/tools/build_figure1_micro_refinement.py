"""v19 local graphic refinement, reusing the frozen v18 layout and renderer."""
from contextlib import redirect_stdout
from copy import deepcopy
import hashlib
import io
import json
import xml.etree.ElementTree as ET

import build_figure1_finish_review as previous

base = previous.base
engine = base.engine
PAPER = base.PAPER
OUT = PAPER / "editable_figures/figure1_v19_micro_refinement"
STEM = "figure1_acdd_workflow_v19_micro_refinement"
PRIOR = previous.OUT
PRIOR_STEM = previous.STEM
FOOTER = "Protected prefix: MIXED · below the 2-pp gate"

class MicroCanvas(engine.canvas.Canvas):
    def setTitle(self, title):
        super().setTitle("ACDD workflow - v19 local graphic refinement")

    def setSubject(self, subject):
        super().setSubject("Schematic workflow for the ACDD manuscript; frozen scientific content")


def near(a, b):
    return abs(a-b) < 1e-6


class MicroScene(previous.FinishScene):
    def export(self):
        before = deepcopy(self.items)
        counts = dict(layers=0, grids=0, attention=0, matrix=0,
                      lock_outlines=0, lock_shift=0, person_lines=0, tag_holes=0,
                      ellipsis=0, footer=0)
        # The exact same layer offsets, cells and token counts are retained.
        for item in self.items:
            k = item["kind"]
            if k == "rect" and item["fill"] in ("#EDF3E8", "#DDEADB", "#BED5BF"):
                assert item["y"] in (120, 122, 124, 164, 166, 168)
                item["fill"] = "#B8CEBC" if item["fill"] == "#BED5BF" else "#E9F0E5"
                counts["layers"] += 1
            if k == "line" and item["stroke"] == "#94B399":
                item.update(stroke="#8FA892", sw=.35)
                counts["grids"] += 1
            if k == "line" and item["stroke"] == base.LAVENDER:
                assert all(166 <= y <= 169 for x, y in item["pts"])
                item.update(stroke="#77638F", sw=.6)
                counts["attention"] += 1
            if k == "rect" and 346 <= item["x"] <= 360 and 262 <= item["y"] <= 280.4:
                assert near(item["w"], 5.8) and near(item["h"], 3.7)
                item.update(fill="#CCDDE4", stroke="#8EA6B1", sw=.35)
                counts["matrix"] += 1
            if (k == "line" and item["stroke"] == base.GRAY and item["sw"] == .7
                    and all(390 <= x <= 470 and 260 <= y <= 280 for x, y in item["pts"])):
                item["sw"] = .65
                counts["person_lines"] += 1
            if k == "ellipse" and item["fill"] == "#FFFFFF" and item["sw"] == .4:
                assert item["stroke"] in (base.BLUE, base.RED, base.GREEN)
                item["sw"] = .45
                counts["tag_holes"] += 1
            if k == "text" and item["text"] == "...":
                assert item["x"] == 457 and item["y"] == 87
                item["y"] = 84
                counts["ellipsis"] += 1
        # Preserve lock construction order: shackle, filled body, keyhole.
        for index, item in enumerate(self.items):
            if item["kind"] != "rect" or item["sw"] != .7:
                continue
            assert item["fill"] == "#FFFFFF" and any(near(item["h"], h) for h in (6.4, 4.8, 4.608))
            group = self.items[index-1:index+2]
            assert [v["kind"] for v in group] == ["ellipse", "rect", "ellipse"]
            for v in group[:2]:
                v["sw"] = .65
                counts["lock_outlines"] += 1
            if near(item["x"], 412):
                # Centre this lock over the existing prefix-to-suffix arrow.
                dx = (393+420)/2 - (412+4*.72)
                for v in group:
                    v["x"] += dx
                counts["lock_shift"] += 1
        for index, item in enumerate(self.items):
            if item.get("text") != FOOTER:
                continue
            parts = [("Protected prefix: ", False, base.MUTED),
                     ("MIXED", True, base.RED),
                     (" · below the 2-pp gate", False, base.MUTED)]
            widths = [engine.pdfmetrics.stringWidth(t, "Arial-Bold" if b else "Arial", item["size"])
                      for t, b, c in parts]
            x = item["x"] - sum(widths)/2
            replacements = []
            for (value, bold, color), width in zip(parts, widths):
                replacements.append(dict(item, text=value, x=x, align="left", bold=bold,
                                         color=color, font="Arial-Bold" if bold else "Arial"))
                x += width
            self.items[index:index+1] = replacements
            counts["footer"] += 1
            break
        assert counts == dict(layers=6, grids=8, attention=3, matrix=15,
                              lock_outlines=6, lock_shift=1, person_lines=8,
                              tag_holes=3, ellipsis=1, footer=1), counts
        assert "".join(i["text"] for i in before if i["kind"] == "text") == \
               "".join(i["text"] for i in self.items if i["kind"] == "text")
        base.refresh_text_boxes(self)
        self.micro_counts = counts
        # Store the approved-layout baseline in memory for the local QA report.
        self.micro_before = before
        return super().export()


def compare_svg():
    old = list(ET.parse(PRIOR / (PRIOR_STEM+".svg")).getroot())
    new = list(ET.parse(OUT / (STEM+".svg")).getroot())
    old_text = "".join(n.text or "" for n in old if n.tag.endswith("}text"))
    new_text = "".join(n.text or "" for n in new if n.tag.endswith("}text"))
    assert old_text == new_text
    # Join the three editorial footer runs for structural comparison.
    j = next(i for i, n in enumerate(new) if n.tag.endswith("}text") and n.text == "Protected prefix: ")
    new[j:j+3] = [new[j]]
    assert len(old) == len(new)
    changed = []
    for index, (a, b) in enumerate(zip(old, new)):
        assert a.tag == b.tag
        if a.attrib == b.attrib and a.text == b.text:
            continue
        kind = a.tag.rsplit("}", 1)[-1]
        changed.append(dict(index=index, kind=kind, before=a.attrib, after=b.attrib,
                            text=a.text if kind == "text" else None))
        if kind == "text":
            assert a.text in (FOOTER, "...")
        elif kind == "rect":
            assert not a.get("stroke-dasharray"), "An outer panel frame changed"
        elif kind == "polyline":
            assert a.get("points") == b.get("points"), "A workflow path moved"
        else:
            assert kind == "ellipse", kind
    # All four outer frames and the entire c panel must be exactly unchanged.
    in_c = False
    for a, b in zip(old, new):
        if a.tag.endswith("}rect") and a.get("stroke-dasharray"):
            assert a.attrib == b.attrib
            in_c = a.get("y") == "136"
        if in_c:
            assert a.attrib == b.attrib and a.text == b.text
    return changed


def build():
    saved = (base.OUT, base.STEM, engine.OUT, engine.STEM, engine.Scene, base.protected_files, engine.canvas.Canvas)
    old_protected = base.protected_files
    # Historical art, sources, current manuscript, and earlier builders are immutable.
    extra = [p for p in (PAPER/"editable_figures").rglob("*") if p.is_file() and OUT not in p.parents]
    extra += [PAPER/"supplementary_standalone.pdf", PAPER/"tools/build_figure1_finish_review.py"]
    base.protected_files = lambda: sorted(set(old_protected()+extra))
    base.OUT, base.STEM, engine.OUT, engine.STEM = OUT, STEM, OUT, STEM
    engine.Scene = MicroScene
    engine.canvas.Canvas = MicroCanvas
    try:
        with redirect_stdout(io.StringIO()):
            base.build()
    finally:
        base.OUT, base.STEM, engine.OUT, engine.STEM, engine.Scene, base.protected_files, engine.canvas.Canvas = saved
    qa_path = OUT / (STEM+"_qa.json")
    qa = json.loads(qa_path.read_text(encoding="utf-8"))
    changes = compare_svg()
    assert qa["words_v17"] == 134 and qa["text_tokens_unchanged"]
    qa.update(scope="v19 local graphic refinement; manuscript adoption is a separate verified step",
              reference_version="v18", text_content_identical_to_v18=True,
              outer_frames_and_formula_panel_identical=True, word_count=134,
              svg_changes=changes, visual_review="pending", native_visio_status="not_generated")
    qa["type_sizes"] = qa.pop("type_sizes_v17")
    for key in ("type_sizes_v16", "words_v16", "words_v17"):
        qa.pop(key, None)
    qa["output_sha256"] = {s: hashlib.sha256((OUT/(STEM+s)).read_bytes()).hexdigest()
                           for s in (".pdf", ".svg", ".png")}
    qa_path.write_text(json.dumps(qa, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in qa.items() if k not in ("text_boxes", "preserved_sha256", "svg_changes")}, indent=2))


if __name__ == "__main__":
    build()
