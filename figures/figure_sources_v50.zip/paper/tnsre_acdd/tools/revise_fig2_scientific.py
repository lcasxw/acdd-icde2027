"""Clarify Fig. 2 scientific comparisons without changing any frozen estimate."""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.text import Text
import numpy as np
from plot_style import BLUE, ORANGE, PALE_BLUE, PALE_ORANGE

PAPER = Path(__file__).resolve().parents[1]
SOURCE = PAPER / "source_data"
PREVIEWS = PAPER / "previews"
PRIOR = PREVIEWS / "reviewer_redesign_20260928"
LAST = PREVIEWS / "fig2_reference_palette_20260929"
OUT = PREVIEWS / "fig2_scientific_revision_20260929"
DATE = datetime(2026, 9, 29, tzinfo=timezone.utc)
INK, MUTED, GRID = "#20262D", "#626C78", "#E4E8EB"
PALETTE = {"negative": "#BCE4F5", "zero": "#F9FCF9", "positive": "#D9F2B3",
           "eegnet": PALE_BLUE, "eeg_conformer": PALE_ORANGE, "level": "#E9EEF2"}
EDGES = {"eegnet": BLUE, "eeg_conformer": ORANGE}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def main():
    source_paths = [SOURCE / "review_construct_cells.csv", SOURCE / "review_absolute_summary.csv"]
    source_hashes = {str(p): sha(p) for p in source_paths}
    preserved = json.loads((PRIOR / "baseline_hashes.json").read_text(encoding="utf-8-sig"))
    earlier_files = [p for directory in (PRIOR, PREVIEWS / "fig2_palette_20260929", LAST)
                     for p in directory.iterdir() if p.is_file()]
    previous_hashes = {str(p): sha(p) for p in earlier_files}
    previous = json.loads((LAST / "qa.json").read_text(encoding="utf-8"))
    cells, absolute = map(read, source_paths)
    assert len(cells) == 135 and sum(int(r["repetitions"]) for r in cells) == 135000
    assert {int(r["sample_size"]) for r in cells} == {40, 80, 160, 320, 640}
    assert {float(r["positive_prior"]) for r in cells} == {.3, .5, .7}
    assert {int(r["seed"]) for r in cells} == {17, 29, 43}
    assert all(float(r["maximum_slope_decision_change"]) == 0 for r in cells)
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["STIXGeneral"], "mathtext.fontset": "stix",
        "font.size": 8.2, "axes.labelsize": 8.2, "xtick.labelsize": 8, "ytick.labelsize": 8,
        "text.color": INK, "axes.labelcolor": INK, "xtick.color": INK, "ytick.color": INK,
        "pdf.fonttype": 42, "svg.fonttype": "path", "svg.hashsalt": "acdd-figure2-closeout-20260929",
        "axes.linewidth": .6, "savefig.facecolor": "white",
    })
    fig = plt.figure(figsize=(6.7, 5.35), dpi=180)
    cmap = LinearSegmentedColormap.from_list("signed_change", [PALETTE[k] for k in ("negative", "zero", "positive")], N=257)
    norm = Normalize(-15, 15)
    fig.text(.025, .977, "Controlled Gaussian-score simulations", fontsize=9, weight="bold", va="center")
    fig.text(.977, .977, "135 design cells | 1,000 repetitions per cell", fontsize=7.5, color=MUTED, ha="right", va="center")
    panels = [
        ("(a)", "Intercept shift", r"$x\ \rightarrow\ s=x+1$", "Level at s; change relative to x", [
            ("mean_intercept_decision_loss", "Decision loss\n(level at $s$, pp)", "level"),
            ("mean_intercept_discrimination_change", "Headroom\nchange", "change")]),
        ("(b)", "Positive scaling", r"$s\ \rightarrow\ 0.2s$", "Changes relative to shifted score s", [
            ("mean_slope_ece_change", "ECE\nchange", "change"),
            ("maximum_slope_decision_change", "Default BA\nchange", "invariant")]),
        ("(c)", "Ranking noise", r"$s\ \rightarrow\ s+\epsilon,\quad\epsilon\sim\mathcal{N}(0,1)$", "Changes relative to shifted score s", [
            ("mean_auc_change_rank_corruption", "AUC\nchange", "change"),
            ("mean_discrimination_change_rank_corruption", "Headroom\nchange", "change")]),
    ]
    aggregation, patches = [], []
    for p, (letter, title, transformation, reference, metrics) in enumerate(panels):
        left = [.105, .420, .735][p]
        fig.text(left - .080, .931, letter, weight="bold", fontsize=10, va="center")
        fig.text(left - .005, .931, title, weight="bold", fontsize=9.5, va="center")
        fig.text(left - .005, .899, transformation, fontsize=8.2, color=MUTED, va="center")
        fig.text(left - .080, .868, reference, fontsize=7.5, color=MUTED, va="center")
        ax = fig.add_axes([left, .640, .185, .204])
        for row, (field, label, kind) in enumerate(metrics):
            for column, d in enumerate((.5, 1., 2.)):
                group = np.array([100 * float(r[field]) for r in cells if float(r["class_separation"]) == d])
                assert len(group) == 45
                mean, low, high = map(float, (group.mean(), group.min(), group.max()))
                face = PALETTE["level"] if kind == "level" else cmap(norm(mean))
                patch = Rectangle((column, row), 1, 1, facecolor=face, edgecolor="white", linewidth=.8,
                                  gid=f"construct-{field}-{d}")
                ax.add_patch(patch)
                patches.append((patch, mean, kind))
                ax.text(column + .5, row + .5, f"{mean:.1f}", ha="center", va="center", fontsize=8.2, color="#111111")
                aggregation.append(dict(panel=p + 1, field=field, class_separation=d, n_cells=45,
                                        mean_pp=mean, design_min_pp=low, design_max_pp=high))
            ax.text(-.12, row + .5, label, ha="right", va="center", fontsize=7.5, linespacing=1.08, clip_on=False)
        ax.set(xlim=(0, 3), ylim=(2, 0), yticks=[])
        ax.set_xticks([.5, 1.5, 2.5], ["0.5", "1.0", "2.0"])
        ax.tick_params(axis="x", length=2.5, pad=2)
        ax.set_xlabel("Class separation, $d$", labelpad=3)
        for side in ("top", "right", "left"):
            ax.spines[side].set_visible(False)
        ax.spines["bottom"].set_color(MUTED)
    cax = fig.add_axes([.946, .640, .012, .204])
    edges = np.linspace(-15, 15, 97)
    for lo, hi in zip(edges[:-1], edges[1:]):
        cax.add_patch(Rectangle((0, lo), 1, hi - lo, facecolor=cmap(norm((lo + hi) / 2)), edgecolor="none"))
    cax.set(xlim=(0, 1), ylim=(-15, 15), xticks=[], yticks=[-15, -10, -5, 0, 5, 10, 15])
    cax.yaxis.tick_right()
    cax.tick_params(axis="y", length=2, pad=2, labelsize=7.5)
    for spine in cax.spines.values():
        spine.set_color(MUTED)
        spine.set_linewidth(.5)
    fig.text(.976, .872, "Change\n(pp)", fontsize=7.5, ha="right", va="center", linespacing=1.0)
    fig.text(.025, .565, "Gray cells: loss level in pp at s. Blue/green: signed change, not benefit.",
             fontsize=7.5, color=MUTED, va="center")
    fig.text(.025, .538, "ECE design ranges (pp; not CIs)", fontsize=7.8, weight="bold", va="center")
    fig.text(.977, .538, "ECE changes vary in sign across design cells.", fontsize=7.5, color=MUTED, ha="right", va="center")
    ranges = [r for r in aggregation if r["field"] == "mean_slope_ece_change"]
    for x, row in zip((.187, .513, .834), ranges):
        assert row["design_min_pp"] < 0 < row["design_max_pp"]
        fig.text(x, .513, f"$d={row['class_separation']:g}$: [{row['design_min_pp']:.2f}, +{row['design_max_pp']:.2f}]",
                 fontsize=8, ha="center", va="center")
    fig.add_artist(Line2D([.025, .977], [.487, .487], transform=fig.transFigure, color=GRID, linewidth=.6))

    fig.text(.025, .461, "(d)  Protected EEG decision audit", fontsize=10, weight="bold", va="center")
    fig.legend(handles=[Line2D([0], [0], color=EDGES[model], linewidth=2.1, marker=marker,
                              markerfacecolor="white", markeredgecolor=INK, markeredgewidth=.8, markersize=3.8, label=label)
                        for model, marker, label in [("eegnet", "o", "EEGNet"), ("eeg_conformer", "D", "EEG-Conformer")]],
               loc="center right", bbox_to_anchor=(.987, .461), ncol=2, frameon=False,
               fontsize=8, handlelength=1.5, handletextpad=.5, columnspacing=1.4, borderaxespad=0)
    fig.text(.025, .430, "Stieger2021 | prefix-10 to suffix | n = 62", fontsize=7.5, color=MUTED, va="center")
    ax = fig.add_axes([.267, .128, .620, .274])
    table = {(r["backbone"], r["metric"]): r for r in absolute}
    metrics = ["headroom", "decision_loss", "gain", "residual_loss"]
    centers = [3.6, 2., 1., 0.]
    names = [r"Oracle headroom, $H_{\mathrm{disc}}$", r"Decision loss, $L_{\mathrm{decision}}$",
             r"Recovered gain, $G_A$", r"Residual loss, $L_A$"]
    meanings = ["Reference above chance", "Oracle - default BA", "Policy - default BA", "Oracle - policy BA"]
    ax.axhspan(3.12, 4.08, facecolor="#F4F6F8", linewidth=0, zorder=0)
    ax.axhline(3.03, color="#C8D0D7", linewidth=.65, zorder=1)
    ax.text(4.075, 2.69, r"$L_{\mathrm{decision}}=G_A+L_A$  (same evaluation trials)",
            fontsize=8.2, color=INK, ha="center", va="center")
    displayed, artists = [], []
    for metric, center, name, meaning in zip(metrics, centers, names, meanings):
        ax.text(-.25, center + .23, name, ha="right", va="center", fontsize=8.4, weight="bold", clip_on=False)
        ax.text(-.25, center - .23, meaning, ha="right", va="center", fontsize=7.5, color=MUTED, clip_on=False)
        for model, offset, marker in [("eegnet", .24, "o"), ("eeg_conformer", -.24, "D")]:
            row = table[model, metric]
            assert int(row["n_participants"]) == 62
            mean, low, high = [100 * float(row[key]) for key in ("mean", "ci_lower", "ci_upper")]
            bar = ax.barh(center + offset, mean, height=.24, facecolor=PALETTE[model],
                          edgecolor=EDGES[model], linewidth=.6, zorder=2)[0]
            bar.set_gid(f"mean-bar-{model}-{metric}")
            point = ax.errorbar(mean, center + offset, xerr=[[mean - low], [high - mean]],
                               color=INK, marker=marker, markerfacecolor="white", markersize=3.0,
                               markeredgewidth=.75, elinewidth=.8, capsize=2, capthick=.7, zorder=4)
            point.lines[0].set_gid(f"mean-point-{model}-{metric}")
            point.lines[2][0].set_gid(f"ci-{model}-{metric}")
            ax.text(8.94, center + offset, f"{mean:.2f}", fontsize=8.2, color=INK, va="center", ha="center", clip_on=False)
            artists.append((bar, point, mean, low, high, center + offset))
            displayed.append(dict(backbone=model, metric=metric, mean_pp=mean, ci_lower_pp=low,
                                  ci_upper_pp=high, interval_provenance=row["interval_provenance"]))
    ax.text(8.94, 4.34, "Mean", fontsize=8, color=MUTED, ha="center", va="center", clip_on=False)
    ax.set(xlim=(0, 8.15), ylim=(-.55, 4.12), yticks=[], xticks=[0, 2, 4, 6, 8])
    ax.grid(axis="x", color=GRID, linewidth=.5, linestyle=(0, (3, 2)), zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(axis="x", length=2.5, pad=2)
    ax.set_xlabel("Balanced-accuracy difference (pp)", labelpad=3)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(MUTED)
    fig.text(.025, .044, "Bars and symbols: means. Whiskers: participant 95% CIs. Oracle uses labels.", fontsize=7.5, color=MUTED)
    fig.text(.025, .019, "Gain CIs are frozen; other CIs are descriptive. Oracle headroom is a separate reference.", fontsize=7.5, color=MUTED)

    assert aggregation == previous["construct_display"]
    assert displayed == previous["protected_components"]
    for bar, point, mean, low, high, y in artists:
        assert bar.get_width() == mean
        np.testing.assert_allclose(np.asarray(point.lines[0].get_xdata(), dtype=float), [mean], rtol=0, atol=1e-12)
        np.testing.assert_allclose(point.lines[2][0].get_segments()[0], [[low, y], [high, y]], rtol=0, atol=1e-12)
    identity_errors = {model: abs(float(table[model, "decision_loss"]["mean"]) - float(table[model, "gain"]["mean"])
                                  - float(table[model, "residual_loss"]["mean"])) for model in ("eegnet", "eeg_conformer")}
    assert max(identity_errors.values()) < 1e-12
    assert all(sha(p) == source_hashes[str(p)] for p in source_paths)
    assert all(sha(Path(r["path"])).upper() == r["sha256"].upper() for r in preserved)
    assert all(sha(Path(p)) == h for p, h in previous_hashes.items())
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    texts = [t for t in fig.findobj(Text) if t.get_visible() and t.get_text()]
    boxes = [t.get_window_extent(renderer) for t in texts]
    outside = [t.get_text() for t, b in zip(texts, boxes)
               if b.x0 < -.5 or b.y0 < -.5 or b.x1 > fig.bbox.width + .5 or b.y1 > fig.bbox.height + .5]
    overlaps = [[texts[i].get_text(), texts[j].get_text()] for i, b in enumerate(boxes)
                for j, c in enumerate(boxes) if j > i and min(b.x1, c.x1) - max(b.x0, c.x0) > .5
                and min(b.y1, c.y1) - max(b.y0, c.y0) > .5]
    assert not outside, outside
    assert not overlaps, overlaps
    assert min(t.get_fontsize() for t in texts) >= 7.5
    OUT.mkdir(parents=True, exist_ok=True)
    base = OUT / "fig2_scientific_revision"
    fig.savefig(base.with_suffix(".pdf"), metadata={"Title": "ACDD Figure 2 - scientific presentation revision", "CreationDate": DATE, "ModDate": DATE})
    fig.savefig(base.with_suffix(".svg"), metadata={"Date": DATE.isoformat()})
    fig.savefig(base.with_suffix(".png"), dpi=400)
    plt.close(fig)
    for name, rows in [("figure_construct_display.csv", aggregation), ("figure_protected_components.csv", displayed)]:
        with (OUT / name).open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    detailed_caption = (
        "Controlled score interventions and protected EEG decision audit. (a-c) Gaussian binary-score simulations "
        "use an unshifted score x and shifted score s=x+1. (a) Gray cells show the absolute decision loss at s, not a "
        "loss change; headroom changes compare s with x. (b) Scores are compressed to 0.2s, and ECE and default-BA "
        "changes compare 0.2s with s. (c) Independent Gaussian noise with SD=1 is added to s; AUC and headroom "
        "changes compare the corrupted scores with s. Blue/green cell colors encode negative/positive change only, "
        "not benefit or harm; they are independent of the model legend in (d). Each class separation summarizes "
        "45 existing design cells over sample sizes 40,80,160,320,640, priors 0.3,0.5,0.7 and seeds 17,29,43 "
        "(135 cells, 1,000 repetitions per cell). Values are means of cell-level means except the default-BA "
        "invariance row, whose source statistic is the maximum absolute change over repetitions within each cell; "
        "every cell is exactly zero. The ECE ranges displayed below the cells are minima and maxima of cell-level "
        "means, not confidence intervals. All three ECE ranges cross zero. The accompanying design-cell summary "
        "table reports all 18 means and design ranges. These simulations do not calibrate the EEG bootstrap CIs. "
        "(d) All quantities use the same protected Stieger2021 prefix-10-to-suffix evaluation trials. Conditions "
        "and seeds are averaged within participant before summarizing n=62 participants. H_disc=BA_oracle-0.5 is a "
        "reference above chance, separate from the identity L_decision=G_A+L_A, where L_decision=BA_oracle-BA_default, "
        "G_A=BA_policy-BA_default and L_A=BA_oracle-BA_policy. Symbols follow the manuscript. The identity applies to unrounded point estimates, "
        "not to marginal CI endpoints. Bar lengths, circle/diamond symbols and the right-hand Mean column report "
        "the same means; whiskers retain the original participant 95% bootstrap CIs. Primary gain CIs remain "
        "frozen; other CIs are post-confirmation descriptive summaries. Oracle quantities use target labels and "
        "are not deployable. The protected result remains mixed.\n")
    (OUT / "figure_caption_detailed.txt").write_text(detailed_caption, encoding="utf-8")
    caption = (
        "Controlled score responses and protected EEG decision audit. "
        "(a-c) Each class separation summarizes 45 design cells (135 total; 1,000 repetitions each). "
        "In (a), gray cells show decision-loss levels at s = x + 1; headroom changes compare s with x. "
        "Panels (b,c) report changes relative to s. Blue/green cells encode change, not benefit. "
        "Values average cell means, except default-BA invariance: all cell maxima of absolute change are exactly zero. "
        "ECE ranges describe design variation, not confidence intervals; the companion table provides all ranges and settings. "
        "(d) All quantities use the same protected prefix-10-to-suffix trials. Source conditions and seeds are averaged "
        "within participant before summarizing 62 participants. Oracle headroom is separate from L_decision = G_A + L_A, "
        "which holds for unrounded means, not marginal interval endpoints. Bars and symbols show means; whiskers retain "
        "participant-bootstrap 95% confidence intervals (gain frozen; others descriptive). Oracles use target labels "
        "and are non-deployable. The protected result remains mixed.\n\n"
        "Abbreviations: BA, balanced accuracy; ECE, expected calibration error; pp, percentage points.\n")
    assert 150 <= len(caption.split()) <= 185, len(caption.split())
    (OUT / "figure_caption.txt").write_text(caption, encoding="utf-8")
    qa = dict(status="pass", preview_only=True, figure_size_inches=[6.7, 5.35], palette=PALETTE,
              source_sha256=source_hashes, source_files_unchanged=True,
              construct_display=aggregation, protected_components=displayed,
              all_estimates_equal_previous_preview=True, actual_mean_and_ci_coordinates_verified=True,
              eeg_identity_absolute_errors=identity_errors,
              after_shift_level_cells_use_uniform_gray=True, colorbar_applies_to_changes_only=True,
              simulation_references="a headroom: s vs x; b: 0.2s vs s; c: s+Gaussian(0,1) vs s; s=x+1",
              default_ba_row="Every cell maximum absolute change is exactly zero",
              ece_design_ranges_visible_in_main_figure=ranges,
              headroom_outside_identity=True, identity_notation="L_decision = G_A + L_A; H_disc is separate",
              fixed_mean_column=True, legend_encodes_model_color_and_shape=True,
              closeout_revision=True, level_unit_pp_explicit=True,
              model_edge_colors=EDGES, model_palette_consistent_with_manuscript=True,
              caption_word_count=len(caption.split()), detailed_caption_retained=True,
              heatmap_count=18, mean_count=8, ci_count=8, minimum_font_pt=7.5,
              text_outside=outside, text_overlaps=overlaps,
              protected_files_byte_identical=len(preserved), previous_preview_files_byte_identical=len(previous_hashes),
              visual_review="pending_final_render")
    (OUT / "figure_qa.json").write_text(json.dumps(qa, indent=2), encoding="utf-8")
    print(base.with_suffix(".pdf"))
    print(base.with_suffix(".png"))


if __name__ == "__main__":
    main()
