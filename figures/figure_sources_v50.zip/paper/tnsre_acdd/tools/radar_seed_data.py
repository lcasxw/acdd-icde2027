"""Build deterministic seed-resolved inputs for the protected Fig. 4 radar.

Only frozen derived gains are reaggregated. No model, policy, interval, or
participant selection is fitted here. Python 3.10 standard library only.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parents[3]
OUT_REL = "paper/tnsre_acdd/plot_data/figure4_seed_radar"
BACKBONES = ("eegnet", "eeg_conformer")
SEEDS = (17, 29, 43)
OMISSION_ORDER = (
    "single-source/BNCI2014_001-to-Stieger2021",
    "single-source/Cho2017-to-Stieger2021",
    "single-source/Lee2019_MI-to-Stieger2021",
    "single-source/PhysionetMI-to-Stieger2021",
    "lodo/Stieger2021",
)
PARTICIPANTS = tuple(f"Stieger2021::{number}" for number in range(1, 63))
TOLERANCE_BA = 1e-12
RADIAL_LIMITS_PP = (-1.0, 5.0)
SOURCES = {
    "policy": "outputs/q1-tnsre-strengthening/stieger/policy_participant_metrics.csv",
    "frozen_mean": "paper/tnsre_acdd/source_data/figure5_leave_one_protocol_out.csv",
}
# Pin both scientific inputs, independently of editable display metadata.
EXPECTED_HASHES = {
    "policy": "bf4b6c5458feeefde95298b5e49b9c4c0966a5dcc159945c6df9215e67d167b7",
    "frozen_mean": "040e622d492ea963aacc303f4abc3eed052d63c19a7a512a13aa4677b3ee03f0",
}
CONTRACT = {
    "candidate": "raw-bn",
    "method": "target_prior_quantile",
    "endpoint": "prefix_suffix",
    "analysis_variant": "main",
    "access_group": "prefix_unlabeled_score",
    "prefix_length": 10,
}
COMMON_FIELDS = ["backbone", *CONTRACT, "omitted_protocol"]
LONG_FIELDS = [
    *COMMON_FIELDS, "seed", "participant_id", "n_protocols_kept",
    "participant_mean_gain", "participant_mean_gain_pp", "retained_protocols",
    "source_rows", "source_path", "source_sha256",
]
SEED_FIELDS = [
    *COMMON_FIELDS, "seed", "n_participants", "n_protocols_kept", "n_source_rows",
    "mean_gain", "mean_gain_pp", "source_path", "source_sha256",
]
FROZEN_FIELDS = [
    *COMMON_FIELDS, "n_participants", "n_protocols_kept", "n_seeds",
    "mean_gain", "mean_gain_pp", "reconstructed_mean_gain",
    "reconstruction_absolute_difference_ba", "source_path", "source_sha256", "source_row",
]


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_csv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for line_number, row in enumerate(csv.DictReader(stream), start=2):
            yield {**row, "_source_row": line_number}


def _write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def build_radar_data(repo_root: Path, output_dir: Path) -> dict:
    """Write 1,860 participant, 30 seed, and 10 frozen-mean rows; return QA.

    Paths in outputs are repository-relative and timestamps are omitted, so the
    anonymous derived-evidence runner can reproduce file hashes independently.
    The thick mean contour must use ``frozen_mean_summary.csv``'s copied values.
    """
    repo_root, output_dir = Path(repo_root).resolve(), Path(output_dir).resolve()
    paths = {name: repo_root / rel for name, rel in SOURCES.items()}
    hashes = {name: _sha256(path) for name, path in paths.items()}
    for name, expected in EXPECTED_HASHES.items():
        _require(hashes[name] == expected, f"Frozen radar source hash changed: {SOURCES[name]}")

    selected = {}
    unit_ids = {}
    for row in _read_csv(paths["policy"]):
        if not all(row.get(field) == CONTRACT[field] for field in
                   ("method", "endpoint", "analysis_variant", "candidate")):
            continue
        key = (row["backbone"], int(row["seed"]), row["protocol_id"], row["participant_id"])
        _require(key not in selected, f"Duplicate protected participant/protocol/seed row: {key}")
        _require(row["dataset_id"] == "Stieger2021", f"Wrong target dataset: {key}")
        _require(row["access_group"] == CONTRACT["access_group"], f"Wrong access contract: {key}")
        _require(int(row["prefix_length"]) == 10, f"Wrong fitting prefix: {key}")
        _require(row["rlls_ridge"] == "", f"Unexpected ridge variant: {key}")
        _require(row["target_labels_available_to_fit"] == "False", f"Target labels in fit: {key}")
        _require(row["uses_future_target_information"] == "False", f"Future target information: {key}")
        gain = float(row["gain"])
        _require(math.isfinite(gain), f"Non-finite frozen gain: {key}")
        selected[key] = {"gain": gain, "source_row": row["_source_row"]}
        unit_key = key[:3]
        _require(unit_key not in unit_ids or unit_ids[unit_key] == row["unit_id"],
                 f"Inconsistent inference unit ID: {unit_key}")
        unit_ids[unit_key] = row["unit_id"]
    expected_keys = {
        (backbone, seed, protocol, participant)
        for backbone in BACKBONES for seed in SEEDS
        for protocol in OMISSION_ORDER for participant in PARTICIPANTS
    }
    _require(set(selected) == expected_keys,
             f"Protected row coverage changed: {len(expected_keys - set(selected))} missing, "
             f"{len(set(selected) - expected_keys)} unexpected")
    _require(len(set(unit_ids.values())) == 30, "Expected 30 distinct protected raw-BN inference units")

    frozen_lookup = {}
    for row in _read_csv(paths["frozen_mean"]):
        key = (row["backbone"], row["omitted_protocol"])
        _require(key not in frozen_lookup, f"Duplicate frozen omission summary: {key}")
        _require(row["endpoint"] == "prefix_suffix" and row["method"] == "target_prior_quantile",
                 f"Wrong frozen omission endpoint/policy: {key}")
        _require(int(row["n_protocols_kept"]) == 4, f"Wrong frozen protocol count: {key}")
        _require(math.isfinite(float(row["mean_gain"])), f"Non-finite frozen mean: {key}")
        frozen_lookup[key] = row
    _require(set(frozen_lookup) == {(b, p) for b in BACKBONES for p in OMISSION_ORDER},
             "Frozen mean table must contain exactly ten backbone/omission groups")

    participant_rows, seed_rows, frozen_rows, group_checks = [], [], [], []
    for backbone in BACKBONES:
        for omitted in OMISSION_ORDER:
            kept = tuple(protocol for protocol in OMISSION_ORDER if protocol != omitted)
            common = {"backbone": backbone, **CONTRACT, "omitted_protocol": omitted}
            means_by_seed = []
            participant_values_by_seed = {}
            for seed in SEEDS:
                gains = []
                for participant in PARTICIPANTS:
                    inputs = [selected[(backbone, seed, protocol, participant)] for protocol in kept]
                    value = mean(item["gain"] for item in inputs)
                    gains.append(value)
                    participant_values_by_seed[(seed, participant)] = value
                    participant_rows.append({
                        **common, "seed": seed, "participant_id": participant,
                        "n_protocols_kept": len(kept), "participant_mean_gain": value,
                        "participant_mean_gain_pp": 100.0 * value,
                        "retained_protocols": "|".join(kept),
                        "source_rows": "|".join(str(item["source_row"]) for item in inputs),
                        "source_path": SOURCES["policy"], "source_sha256": hashes["policy"],
                    })
                seed_mean = mean(gains)
                means_by_seed.append(seed_mean)
                seed_rows.append({
                    **common, "seed": seed, "n_participants": len(gains),
                    "n_protocols_kept": len(kept), "n_source_rows": len(gains) * len(kept),
                    "mean_gain": seed_mean, "mean_gain_pp": 100.0 * seed_mean,
                    "source_path": SOURCES["policy"], "source_sha256": hashes["policy"],
                })
            original = frozen_lookup[(backbone, omitted)]
            original_mean = float(original["mean_gain"])
            reconstructed = mean(means_by_seed)
            # Also confirm the original participant-first estimand, independently
            # of the equal-cell algebra used for the seed contours.
            participant_first = mean(
                mean(participant_values_by_seed[(seed, participant)] for seed in SEEDS)
                for participant in PARTICIPANTS
            )
            difference = abs(reconstructed - original_mean)
            _require(difference <= TOLERANCE_BA, f"Frozen mean reconstruction failed: {backbone}, {omitted}")
            _require(abs(participant_first - original_mean) <= TOLERANCE_BA,
                     f"Participant-first mean reconstruction failed: {backbone}, {omitted}")
            frozen_rows.append({
                **common, "n_participants": len(PARTICIPANTS), "n_protocols_kept": len(kept),
                "n_seeds": len(SEEDS), "mean_gain": original["mean_gain"],
                "mean_gain_pp": 100.0 * original_mean, "reconstructed_mean_gain": reconstructed,
                "reconstruction_absolute_difference_ba": difference,
                "source_path": SOURCES["frozen_mean"], "source_sha256": hashes["frozen_mean"],
                "source_row": original["_source_row"],
            })
            group_checks.append({
                "backbone": backbone, "omitted_protocol": omitted,
                "seed_means_ba": dict(zip(map(str, SEEDS), means_by_seed)),
                "frozen_mean_ba": original_mean, "seed_average_ba": reconstructed,
                "participant_first_average_ba": participant_first,
                "absolute_difference_ba": difference, "n_participants_per_seed": 62,
                "n_protocols_kept": 4, "participant_ids_complete": True,
            })

    negatives = [
        {field: row[field] for field in ("backbone", "omitted_protocol", "seed", "mean_gain_pp")}
        for row in seed_rows if row["mean_gain"] < 0.0
    ]
    _require(len(negatives) == 2, "Frozen seed contour must retain both negative mean values")
    displayed = [row["mean_gain_pp"] for row in [*seed_rows, *frozen_rows]]
    _require(all(RADIAL_LIMITS_PP[0] <= value <= RADIAL_LIMITS_PP[1] for value in displayed),
             "A frozen contour value exceeds the shared -1 to 5 pp display")
    _require(len(participant_rows) == 1860 and len(seed_rows) == 30 and len(frozen_rows) == 10,
             "Unexpected output row counts")

    output_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(output_dir / "participant_long.csv", participant_rows, LONG_FIELDS)
    _write_csv(output_dir / "seed_summary.csv", seed_rows, SEED_FIELDS)
    _write_csv(output_dir / "frozen_mean_summary.csv", frozen_rows, FROZEN_FIELDS)
    readme = """# Figure 4: seed-resolved source-omission radar inputs

This is a deterministic reaggregation of frozen raw-BN target-prior-quantile
results at the protected prefix-10-to-suffix endpoint. The scientific branch
remains mixed. No training, policy fit, bootstrap, or new confidence interval is
performed. No participant is removed, and no future scores or target labels are
available to the original deployable policy fit.

For each backbone, omitted source condition, seed, and participant, average the
four retained source-condition BA gains. Then average the same 62 participant
means to obtain the seed contour. The arithmetic mean over seeds 17, 29, and 43
reconstructs every original frozen omission mean to within 1e-12 BA. The thick
mean contour uses the copied frozen mean, not a replacement estimate.

- participant_long.csv: 1,860 participant/seed/omission/backbone rows, with four
  source line references per row; these are not 1,860 independent participants.
- seed_summary.csv: 30 descriptive seed-specific cohort means.
- frozen_mean_summary.csv: ten original mean strings plus reconstruction checks.
- qa_report.json: frozen input hashes, coverage, negative means and output hashes.

Fixed spoke order is BNCI2014-001, Cho2017, Lee2019-MI, PhysioNetMI, LODO. Each
spoke names the omitted training condition; all evaluation uses Stieger2021.
Both backbone panels use true BA gain in percentage points on one -1 to 5 pp
scale, with an explicit zero ring. Preserve the two negative seed means. Seed
contours are descriptive training-seed sensitivity, not confidence intervals;
the overlapping omission groups are not independent cohorts. Polygon area is
not an outcome, and mean positivity does not imply universal participant benefit.

Rebuild with the standard-library-only module:

    python paper/tnsre_acdd/tools/radar_seed_data.py --repo-root .

An independent runner can choose --output-dir without changing output bytes.
"""
    (output_dir / "README.md").write_text(readme, encoding="utf-8", newline="\n")
    output_names = ("participant_long.csv", "seed_summary.csv", "frozen_mean_summary.csv", "README.md")
    report = {
        "schema_version": 1, "status": "pass", "protected_scientific_branch": "mixed",
        "scope": "Descriptive seed-resolved source-omission reaggregation of frozen participant gains",
        "contract": CONTRACT,
        "input_selected_rows": len(selected), "inference_units": len(unit_ids),
        "participant_rows": len(participant_rows), "seed_summary_rows": len(seed_rows),
        "frozen_mean_rows": len(frozen_rows), "unique_participants": len(PARTICIPANTS),
        "participant_ids": list(PARTICIPANTS), "backbones": list(BACKBONES),
        "seeds": list(SEEDS), "omission_order": list(OMISSION_ORDER),
        "n_protocols_kept": 4, "duplicate_selected_rows": 0,
        "all_backbone_seed_protocol_participant_cells_present": True,
        "same_participants_in_every_group": True,
        "target_labels_available_to_fit": False, "uses_future_target_information": False,
        "source_access_flags_verified": True,
        "no_new_policy_fits": True, "no_bootstrap_or_intervals_computed": True,
        "all_original_mean_strings_preserved": True, "all_frozen_means_match": True,
        "tolerance_ba": TOLERANCE_BA,
        "maximum_mean_absolute_difference_ba": max(row["absolute_difference_ba"] for row in group_checks),
        "negative_seed_mean_count": len(negatives), "negative_seed_means": negatives,
        "minimum_seed_mean_pp": min(row["mean_gain_pp"] for row in seed_rows),
        "maximum_seed_mean_pp": max(row["mean_gain_pp"] for row in seed_rows),
        "shared_radial_limits_pp": list(RADIAL_LIMITS_PP), "zero_ring_pp": 0.0,
        "all_displayed_means_within_shared_radial_limits": True,
        "source_hashes": {SOURCES[name]: hashes[name] for name in SOURCES},
        "group_checks": group_checks,
        "output_sha256": {name: _sha256(output_dir / name) for name in output_names},
        "interpretation": [
            "Seed contours are descriptive sensitivity, not confidence intervals.",
            "Participants recur across seeds, omissions and backbones; groups are not independent cohorts.",
            "A spoke names the omitted source-training condition; the target remains Stieger2021.",
            "The original frozen mean contour and protected mixed branch remain unchanged.",
            "No normalization, ranking by observed outcome or polygon-area score is introduced.",
        ],
    }
    (output_dir / "qa_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n",
    )
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=ROOT)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    output = args.output_dir if args.output_dir is not None else args.repo_root / OUT_REL
    report = build_radar_data(args.repo_root, output)
    print(json.dumps({
        "status": report["status"], "output_dir": str(output.resolve()),
        "participant_rows": report["participant_rows"], "seed_summary_rows": report["seed_summary_rows"],
        "frozen_mean_rows": report["frozen_mean_rows"],
        "maximum_mean_absolute_difference_ba": report["maximum_mean_absolute_difference_ba"],
        "negative_seed_mean_count": report["negative_seed_mean_count"],
    }, indent=2))


if __name__ == "__main__":
    main()
