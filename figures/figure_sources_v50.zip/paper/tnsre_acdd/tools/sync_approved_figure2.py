"""Synchronize the approved Figure 2 and its complete simulation-range table.

Artwork is copied byte-for-byte; source checks never recompute EEG intervals.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from pathlib import Path
from statistics import mean

PAPER = Path(__file__).resolve().parents[1]
ARCHIVE = PAPER / "editable_figures/figure2_scientific_approved_20260930"
STEM = "figure2_construct_protected_audit"
FIELDS = (
    ("mean_intercept_decision_loss", "(a) Decision loss after shift", r"Level at $s=x+1$"),
    ("mean_intercept_discrimination_change", "(a) Oracle headroom change", r"$s$ versus $x$"),
    ("mean_slope_ece_change", "(b) ECE change", r"$0.2s$ versus $s$"),
    ("maximum_slope_decision_change", "(b) Default-BA invariance", "Maximum absolute change per cell"),
    ("mean_auc_change_rank_corruption", "(c) AUC change", r"$s+\epsilon$ versus $s$"),
    ("mean_discrimination_change_rank_corruption", "(c) Oracle headroom change", r"$s+\epsilon$ versus $s$"),
)


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def verify(source: Path) -> None:
    for name, expected in json.loads((ARCHIVE / "archive_sha256.json").read_text()).items():
        if hashlib.sha256((ARCHIVE / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Approved Figure 2 archive changed: {name}")
    cells = rows(source / "review_construct_cells.csv")
    assert len(cells) == 135 and all(int(r["repetitions"]) == 1000 for r in cells)
    for r in rows(ARCHIVE / "fig2_design_ranges.csv"):
        values = [100 * float(c[r["field"]]) for c in cells
                  if float(c["class_separation"]) == float(r["class_separation"])]
        assert len(values) == 45
        for key, value in zip(("mean_pp", "design_min_pp", "design_max_pp"),
                              (mean(values), min(values), max(values))):
            assert abs(float(r[key]) - value) < 1e-11, (r["field"], key)
    absolute = {(r["backbone"], r["metric"]): r
                for r in rows(source / "review_absolute_summary.csv")}
    for r in rows(ARCHIVE / "figure_protected_components.csv"):
        ref = absolute[(r["backbone"], r["metric"])]
        assert int(ref["n_participants"]) == 62
        for key in ("mean", "ci_lower", "ci_upper"):
            assert abs(float(r[key + "_pp"]) - 100 * float(ref[key])) < 1e-11
        assert r["interval_provenance"] == ref["interval_provenance"]


def build_table(output: Path) -> None:
    from build_supplementary_tables import longtable
    data = {(r["field"], float(r["class_separation"])): r
            for r in rows(ARCHIVE / "fig2_design_ranges.csv")}
    table_rows = []
    for field, label, reference in FIELDS:
        values = []
        for d in (0.5, 1.0, 2.0):
            r = data[field, d]
            values.append(f"{float(r['mean_pp']):.2f} [{float(r['design_min_pp']):.2f}, {float(r['design_max_pp']):.2f}]")
        table_rows.append([label + r"\newline\textit{" + reference + "}", *values])
    note = (
        r"Values are means [design minimum, design maximum], in percentage points; ranges are not confidence intervals. "
        r"Each separation summarizes 45 cells: five sample sizes $n\in\{40,80,160,320,640\}$, "
        r"three positive-class priors $\{0.3,0.5,0.7\}$, and three seeds $\{17,29,43\}$. "
        r"The full design has 135 cells with 1,000 repetitions each. Unit-variance Gaussian classes have means $\pm d/2$; "
        r"$s=x+1$, the scale is 0.2, and $\epsilon\sim\mathcal{N}(0,1)$. "
        r"Responses average within-cell repetition means except default-BA invariance, which uses the within-cell "
        r"maximum absolute change (exactly zero in all cells). Every ECE design range crosses zero. "
        r"The decision-loss row is an absolute level, not a change. These simulations do not validate EEG bootstrap intervals."
    )
    tex = longtable(
        "Complete simulation-design summaries for main Fig. 2(a--c).",
        "tab:figure2_design_ranges",
        r"L{0.34\linewidth}C{0.20\linewidth}C{0.20\linewidth}C{0.20\linewidth}",
        ["Response and comparison", "$d=0.5$", "$d=1.0$", "$d=2.0$"], table_rows, note,
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(tex) + "\n", encoding="utf-8")


def sync(figures: Path, source: Path) -> list[Path]:
    verify(source)
    figures.mkdir(parents=True, exist_ok=True)
    outputs = []
    for ext in ("pdf", "svg", "png"):
        target = figures / f"{STEM}.{ext}"
        shutil.copyfile(ARCHIVE / f"fig2_scientific_revision.{ext}", target)
        outputs.append(target)
    return outputs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--figures", type=Path, default=PAPER / "figures")
    parser.add_argument("--source", type=Path, default=PAPER / "source_data")
    parser.add_argument("--table", type=Path, default=PAPER / "generated/figure2_design_ranges.tex")
    args = parser.parse_args()
    outputs = sync(args.figures, args.source)
    build_table(args.table)
    print(json.dumps({"status": "pass", "artwork": [str(p) for p in outputs], "table": str(args.table)}, indent=2))


if __name__ == "__main__":
    main()
