"""Author-requested 3D oracle comparison with source-exact endpoint CIs.

An explicit affine 3D-to-page projection provides reproducible vector geometry.
The depth coordinate separates categories; it is not a measured quantity.
"""
from pathlib import Path
import csv, json, hashlib, os
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parents[3]/'.mplconfig'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.text import Text
from plot_style import save_figure, apply_publication_style

PAPER=Path(__file__).resolve().parents[1]
W,H=3.41718,3.72
C={'eegnet_headroom':'#247C82','eegnet_decision_loss':'#B18428',
   'eeg_conformer_headroom':'#9873B3','eeg_conformer_decision_loss':'#C86653'}
INK='#27343E'; MUTED='#66737D'; GRID='#DCE2E7'
# Magnitude-ordered depth makes the smaller series visible in front.
LANES=[('eegnet','decision_loss'),('eeg_conformer','decision_loss'),('eeg_conformer','headroom'),('eegnet','headroom')]
MODEL={'eegnet':'EEGNet','eeg_conformer':'EEG-Conformer'}
METRIC={'headroom':'Headroom','decision_loss':'Decision loss'}

def build_figure7_single_column(figures: Path, source: Path, qa_dir: Path | None = None) -> list[Path]:
    OUT=Path(figures)
    OUT.mkdir(parents=True,exist_ok=True)
    QA=Path(qa_dir) if qa_dir else OUT.parent/'plot_data/figure7_oracle_single_column'
    QA.mkdir(parents=True,exist_ok=True)
    source=Path(source)
    source_path=source/'figure4_cross_fitted_oracle.csv'
    source_hash=hashlib.sha256(source_path.read_bytes()).hexdigest()
    with source_path.open(encoding='utf-8-sig',newline='') as f:
        source=list(csv.DictReader(f))
    D={(r['backbone'],r['metric']):r for r in source}
    assert len(D)==8

    apply_publication_style()
    plt.rcParams.update({'font.family':'DejaVu Sans','text.color':INK,'font.size':7.5,
                        'savefig.bbox':None,'svg.hashsalt':'oracle-single-column-refined-20261003'})
    fig=plt.figure(figsize=(W,H))
    ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,W),ylim=(0,H));ax.axis('off');ax.set_aspect('equal')

    def P(x,y,z):
        return np.asarray([.42+1.90*x+.27*y,.99+.10*y+.26*z])
    def line(a,b,**kwargs):
        u=P(*a);v=P(*b)
        artist,=ax.plot([u[0],v[0]],[u[1],v[1]],**kwargs)
        return artist
    def poly(points,**kwargs):
        patch=Polygon(np.asarray([P(*p) for p in points]),closed=True,**kwargs);ax.add_patch(patch);return patch
    def text(x,y,s,size=7.5,color=INK,ha='left',va='center',weight='normal',rotation=0,zorder=20,**kwargs):
        return ax.text(x,y,s,fontsize=size,color=color,ha=ha,va=va,fontweight=weight,rotation=rotation,
                       rotation_mode='anchor',zorder=zorder,**kwargs)

    text(.08,3.60,'Oracle sensitivity to cross-fitting',size=8.4,weight='bold')

    # A light zero plane anchors the four surfaces without enclosing them in a box.
    # Depth is categorical; equal-height guides map each lane to the front ruler.
    ylo,yhi=-.30,3.25; zmax=8.4
    poly([(0,ylo,0),(1,ylo,0),(1,yhi,0),(0,yhi,0)],facecolor='#FCFDFD',edgecolor=GRID,lw=.45,zorder=0)
    for z in [0,2,4,6,8]:
        line((0,ylo,z),(0,yhi,z),color='#D7DEE3',lw=.4,zorder=1)
    line((0,ylo,0),(1,ylo,0),color='#B4C0C8',lw=.55,zorder=2)
    line((1,ylo,0),(1,yhi,0),color='#B4C0C8',lw=.55,zorder=2)
    text(.075,2.03,'BA difference (pp)',size=7.4,rotation=90,ha='center')

    # One outside front-left scale; no rear ruler passes through the data.
    ruler_ticks=[]
    line((0,ylo,0),(0,ylo,zmax),color='#9CAAB5',lw=.65,zorder=3)
    for z in [0,2,4,6,8]:
        xx,yy=P(0,ylo,z)
        ax.plot([xx-.035,xx],[yy,yy],color='#7D8B96',lw=.6,zorder=3)
        text(xx-.065,yy,str(z),size=7.4,color=MUTED,ha='right',zorder=35)
        ruler_ticks.append(dict(lane=ylo,value_pp=z,page_x=xx,page_y=yy))

    # Back-to-front ordering keeps geometric overlap predictable.
    records=[]; reductions=[]; grounded_faces=[]
    for lane in reversed(range(4)):
        m,metric=LANES[lane]
        color=C[m+'_'+metric]
        values={phase:[float(D[m,phase+'_'+metric][k])*100 for k in ['ci_lower','point','ci_upper']]
                for phase in ['in_sample','cross_fitted']}
        before=values['in_sample'][1];after=values['cross_fitted'][1]
        dash='-' if metric=='headroom' else (0,(3,2))
        layer=4+(3-lane)*3
        # Each solid reaches the same zero plane. Its depth is geometric, not data.
        width=.16
        front=[(0,lane-width,0),(1,lane-width,0),
               (1,lane-width,after),(0,lane-width,before)]
        poly(front,facecolor=color,alpha=.035,edgecolor='none',zorder=layer)
        for x,height in [(0,before),(1,after)]:
            # The filled face reaches zero without an extra vertical stroke beside
            # the statistical whisker. Only the short floor edge is outlined.
            line((x,lane-width,0),(x,lane+width,0),color=color,lw=.5,alpha=.45,zorder=layer+.2)
        poly([(0,lane-width,before),(1,lane-width,after),(1,lane+width,after),(0,lane+width,before)],
             facecolor=color,alpha=.12,edgecolor='none',zorder=layer+.2)
        grounded_faces.append(dict(lane=lane,color=color,front_vertices=front,baseline_z=0))
        line((0,lane-width,0),(1,lane-width,0),color=color,lw=.6,alpha=.55,zorder=layer+.3)
        # A single light top edge supplies depth; the central line carries the data.
        line((0,lane+width,before),(1,lane+width,after),color=color,lw=.4,alpha=.38,ls=dash,zorder=30)
        line((0,lane,before),(1,lane,after),color=color,lw=1.2,ls=dash,zorder=31)
        for x,phase in [(0,'in_sample'),(1,'cross_fitted')]:
            lo,mean,hi=values[phase]
            assert 0<lo<mean<hi<zmax
            stem=line((x,lane,lo),(x,lane,hi),color=color,lw=.85,zorder=32)
            expected=np.stack([P(x,lane,lo),P(x,lane,hi)])
            assert np.allclose(np.column_stack([stem.get_xdata(),stem.get_ydata()]),expected,atol=1e-12)
            for z in [lo,hi]:
                xx,yy=P(x,lane,z)
                ax.plot([xx-.035,xx+.035],[yy,yy],color=color,lw=.8,zorder=33)
            xx,yy=P(x,lane,mean)
            marker='o' if m=='eegnet' else 'D'
            ax.plot(xx,yy,marker=marker,ms=4.2,mfc=color if metric=='headroom' else 'white',
                    mec=color,mew=.95,ls='none',zorder=34)
            # One consistent offset above each CI; initial labels sit slightly
            # right of the whisker so the front ruler stays unobscured.
            text(xx+(.11 if x==0 else 0),P(x,lane,hi)[1]+.105,
                 f'{mean:.2f}',size=7.6,color=color,weight='bold',ha='center',zorder=40)
            records.append(dict(backbone=m,metric=metric,phase=phase,lane=lane,mean_pp=mean,ci_lower_pp=lo,ci_upper_pp=hi,ci_projection_exact=True))
        delta=after-before;pct=(before-after)/before*100
        if m=='eeg_conformer' and metric=='decision_loss':assert f'{pct:.1f}'=='39.6'
        # Keep only the compact absolute change in the plotting area.
        # Relative changes are retained beside the corresponding legend entry.
        label_x=.54
        midpoint=P(label_x,lane,before+label_x*(after-before)-.60)
        text(*midpoint,f'−{abs(delta):.2f} pp',size=7.2,color=color,
             ha='center',weight='normal',zorder=40)
        reductions.append(dict(backbone=m,metric=metric,change_pp=delta,relative_decrease_percent=pct))

    # Compact two-column legend retains all four full series identities.
    # Line style identifies the metric; marker shape identifies the backbone.
    text(.42,.825,'In-sample',size=7.5,ha='center')
    text(2.32,.825,'Cross-fitted',size=7.5,ha='center')
    for col,m in enumerate(['eegnet','eeg_conformer']):
        x=.12+1.65*col
        text(x+.35,.635,MODEL[m],size=7.2,weight='bold')
        for row,metric in enumerate(['headroom','decision_loss']):
            y=.455-.18*row
            color=C[m+'_'+metric];dash='-' if metric=='headroom' else (0,(3,2))
            ax.plot([x,x+.27],[y,y],color=color,lw=1.2,ls=dash)
            ax.plot(x+.135,y,marker='o' if m=='eegnet' else 'D',ms=4.3,
                    mfc=color if metric=='headroom' else 'white',mec=color,mew=.9,ls='none')
            pct=next(r['relative_decrease_percent'] for r in reductions
                     if r['backbone']==m and r['metric']==metric)
            text(x+.35,y,f'{METRIC[metric]} (−{pct:.1f}%)',size=7.2,color=MUTED)
    legend_x,legend_y=.22,.09
    ax.plot([legend_x,legend_x],[legend_y-.070,legend_y+.070],color=INK,lw=.8)
    for cap_y in [legend_y-.070,legend_y+.070]:
        ax.plot([legend_x-.03,legend_x+.03],[cap_y,cap_y],color=INK,lw=.8)
    ax.plot(legend_x,legend_y,marker='o',ms=3.5,mfc=INK,mec=INK,ls='none')
    text(.36,.09,'Mean and 95% CI',size=7.2)
    text(2.64,.09,'n = 62',size=7.2,color=MUTED)

    fig.canvas.draw();renderer=fig.canvas.get_renderer()
    texts=[t for t in fig.findobj(Text) if t.get_visible() and t.get_text().strip()]
    boxes=[(t,t.get_window_extent(renderer)) for t in texts]
    clip=[];overlap=[];actual_overlap=[]
    def polygons_overlap(a,b):
        # Separating-axis test for the actual rotated rectangular text boxes.
        for vertices in [a,b]:
            for edge in np.roll(vertices,-1,axis=0)-vertices:
                if np.linalg.norm(edge)<1e-8:continue
                normal=np.asarray([-edge[1],edge[0]])/np.linalg.norm(edge)
                pa=a@normal;pb=b@normal
                if pa.max()<=pb.min()+.5 or pb.max()<=pa.min()+.5:return False
        return True
    def text_polygon(t,b):
        patch=t.get_bbox_patch()
        if patch is not None:
            vertices=patch.get_path().transformed(patch.get_transform()).vertices
            return vertices[:-1]
        return np.asarray([[b.x0,b.y0],[b.x1,b.y0],[b.x1,b.y1],[b.x0,b.y1]])
    for t,b in boxes:
        if b.x0<-.5 or b.y0<-.5 or b.x1>fig.bbox.width+.5 or b.y1>fig.bbox.height+.5:clip.append(t.get_text())
    for i,(ta,a) in enumerate(boxes):
        for tb,b in boxes[i+1:]:
            dx=min(a.x1,b.x1)-max(a.x0,b.x0);dy=min(a.y1,b.y1)-max(a.y0,b.y0)
            if dx>1 and dy>1:
                overlap.append([ta.get_text(),tb.get_text()])
                if polygons_overlap(text_polygon(ta,a),text_polygon(tb,b)):
                    actual_overlap.append([ta.get_text(),tb.get_text()])
    qa=dict(minimum_font_pt=min(t.get_fontsize() for t in texts),text_count=len(texts),clipped=clip,
            axis_aligned_bbox_overlap_candidates=overlap,actual_rotated_text_overlaps=actual_overlap,n_endpoint_triples=len(records),projection='affine orthographic',
            projection_origin=[.42,.99],projection_x=[1.90,0],projection_y=[.27,.10],projection_z=[0,.26],
            distinct_colors=len(set(C.values())),grounded_faces=grounded_faces,ruler_ticks=ruler_ticks,
            data_vertical_outline_strokes=0,mean_ci_symbol_legend=True,delta_labels=4,
            line_style_legend={'solid':'Headroom','dashed':'Decision loss'})
    exports=save_figure(fig,OUT/'figure6_oracle_sensitivity.pdf')
    fig.savefig(QA/'preview.png',dpi=180,bbox_inches=None,facecolor='white')
    plt.close(fig)
    (QA/'source_and_layout_qa.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
    assert len(records)==8 and not clip and not actual_overlap
    assert all(P(0,lane,0)[1]==P(1,lane,0)[1] for lane in range(4))
    assert len(ruler_ticks)==5
    assert all(abs(t['page_y']-P(0,t['lane'],t['value_pp'])[1])<1e-12 for t in ruler_ticks)
    assert all(abs(P(1,r['lane'],r['mean_pp'])[1]-P(0,r['lane'],r['mean_pp'])[1])<1e-12 for r in records)
    assert len(set(C.values()))==4 and len(grounded_faces)==4
    assert all(f['front_vertices'][0][2]==f['front_vertices'][1][2]==0 for f in grounded_faces)
    assert hashlib.sha256(source_path.read_bytes()).hexdigest()==source_hash
    qa['source_sha256']=source_hash
    (QA/'source_and_layout_qa.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
    for name,rows in [('displayed_estimates',records),('displayed_changes',reductions)]:
        with (QA/(name+'.csv')).open('w',encoding='utf-8',newline='') as f:
            wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
    manifest=dict(chart_type='author-requested orthographic 3D grounded paired comparison',paired_data=True,pairing_preserved=True,
        x_categories_ordered=True,uncertainty_present=True,uncertainty_label='vertical participant bootstrap 95% CI at each endpoint',
        statistical_unit='participant after frozen source-condition and seed averaging',minimum_font_pt=7.2,final_width_in=W,
        panel_count=1,series_count=4,legend_count=1,color_redundancy=True,palette_hex=C,
        export_formats=['pdf','svg','png'],raster_dpi=600,final_size_checked=True,
        user_requested_3d=True,depth_is_categorical=True,surfaces_are_confidence_bands=False,
        surfaces_extend_to_zero=True,distinct_series_colors=4,horizontal_comparison_baseline=True,local_depth_rulers=0,main_rulers=1,
        depth_order='ascending mean at both endpoints',change_annotations='delta = descriptive unrounded mean difference; no significance claim',
        mean_ci_symbol_legend=True,data_vertical_outline_strokes=0,
        main_ruler_position='front-left outside data',relative_changes_in_legend=True,front_face_alpha=.035,background_walls=False,
        line_style_legend={'solid':'Headroom','dashed':'Decision loss'})
    (QA/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (QA/'palette.json').write_text(json.dumps(C,indent=2),encoding='utf-8')
    caption='Oracle sensitivity to cross-fitting. Four categorical depth lanes separate backbone and metric, ordered from smaller to larger mean at both endpoints. Depth, thickness and filled area have no additional quantitative meaning. A single outside front-left ruler has 0-8 pp ticks; oblique guides connect equal values across depth lanes. Absolute page height across lanes includes the categorical depth offset. The setting direction is horizontal and the common z scale is 0.26 inches per percentage point. Teal denotes EEGNet headroom, ochre EEGNet decision loss, purple EEG-Conformer headroom, and coral EEG-Conformer decision loss. Circles identify EEGNet and diamonds EEG-Conformer; solid connectors with filled markers denote headroom, while dashed connectors with open markers denote decision loss. Light translucent faces extend from the two means to z=0; they are not uncertainty bands. Sloping tops connect only the observed means and do not imply an intermediate measured trajectory. Means average 62 participants after frozen source-condition and seed averaging. Whiskers preserve the original participant-bootstrap 95% confidence intervals. In-plot labels give cross-fitted minus in-sample changes in percentage points; legend percentages give the same change relative to the unrounded in-sample mean. Endpoint CIs are not CIs for paired changes and do not establish change significance. Both settings use target labels and complete sessions, with leave-one-session-out cross-fitting; neither is a deployable policy or a guaranteed bound on dynamic policies. These quantities do not use the protected prefix-10 suffix. Equal absolute changes in both metrics within a backbone reflect their shared oracle term.'
    (QA/'caption.txt').write_text(caption+'\n',encoding='utf-8')
    return exports

if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--figures',type=Path,default=PAPER/'previews/figure7_refinement_v44')
    parser.add_argument('--source',type=Path,default=PAPER/'source_data')
    parser.add_argument('--qa-dir',type=Path)
    args=parser.parse_args()
    for path in build_figure7_single_column(args.figures,args.source,args.qa_dir):
        print(path)
