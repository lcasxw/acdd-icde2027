"""Typography-refined v17 Fig. 1 review; never replaces approved manuscript assets.

Reuses the unchanged v15 vector renderer, not its scene. Every signal, feature,
permission and aggregation glyph is schematic; no plot/data values are invented.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
import subprocess
from pathlib import Path

import build_figure1_icon_review as engine

PAPER = engine.PAPER
OUT = PAPER / "editable_figures/figure1_v17_typography_review"
STEM = "figure1_acdd_workflow_v17_typography_review"
W, H = 482.4, 330.0
INK, MUTED = engine.INK, engine.MUTED
BLUE, GRAY, RED = engine.BLUE, engine.GRAY, engine.RED
GREEN, LAVENDER = "#61816A", "#8A78A5"
engine.OUT, engine.STEM, engine.W, engine.H = OUT, STEM, W, H


def math_terms(s, x, y, runs, size=10.5):
    """One equation tier; variables italic, descriptive subscript upright."""
    for word, sub, color in runs:
        x += s.text(x,y+2.1 if sub else y,word,7 if sub else size,color,
                    italic=word.strip() in ("G","L","A"))
    return x


def tighten_main_column(s, start):
    """Recover 4 pt for the side column, without scaling any type sizes."""
    factor=318/322
    for item in s.items[start:]:
        if "pts" in item:
            item["pts"]=[(4+(x-4)*factor,y) for x,y in item["pts"]]
        elif "x" in item:
            item["x"]=4+(item["x"]-4)*factor
            if "w" in item: item["w"]*=factor


def refresh_text_boxes(s):
    s.text_boxes=[]
    for item in s.items:
        if item["kind"]!="text": continue
        width=engine.pdfmetrics.stringWidth(item["text"],item["font"],item["size"])
        x=item["x"]-(width/2 if item["align"]=="center" else width if item["align"]=="right" else 0)
        s.text_boxes.append(dict(text=item["text"],x=x,y=item["y"]-item["size"]*.9,
                                 w=width,h=item["size"]*1.15,size=item["size"]))


def chip(s, x, y, w, h, label, color, fill="#FFFFFF", size=7):
    s.rect(x, y, w, h, fill, color, .4, 2)
    s.text(x+w/2, y+h/2+size*.34, label, size, color, align="center")


def scores(s, x, y, color=BLUE, stacked=False, n=5):
    """Equal token sizes: membership, never score magnitudes."""
    if stacked:
        for dx, dy in ((4, -4), (2, -2)):
            s.rect(x+dx, y+dy, n*4.5+4, 15, "#FFFFFF", color, .4, 1)
    s.rect(x, y, n*4.5+4, 15, "#FFFFFF", color, .5, 1)
    for j in range(n):
        s.rect(x+3+j*4.5, y+3, 2.9, 9, "#CFDFE8", color, .3, .3)


def slider(s, x, y, color, size=1):
    """Threshold-setting control; not a quantitative threshold or distribution."""
    s.rect(x, y, 25*size, 20*size, "#FFFFFF", color, .5, 2)
    for yy, px in ((6, 10), (14, 17)):
        s.line([(x+4*size, y+yy*size), (x+21*size, y+yy*size)], color, .65)
        s.ellipse(x+px*size, y+yy*size, 1.8*size, fill="#FFFFFF", stroke=color, sw=.65)


def head(s, x, y, scale=1):
    s.ellipse(x, y, 11*scale, 11*scale, "#FFFFFF", MUTED, .65)
    s.line([(x-2*scale,y-10.8*scale),(x,y-13.2*scale),(x+2*scale,y-10.8*scale)], MUTED, .6)
    for side in (-1, 1):
        s.line([(x+side*11*scale,y-4*scale),(x+side*12.5*scale,y-3*scale),
                (x+side*12.5*scale,y+3*scale),(x+side*11*scale,y+4*scale)], MUTED, .6)
    for xx, yy in ((-4.6,-5),(4.6,-5),(-6,0),(0,0),(6,0),(-5,5),(0,6),(5,5)):
        s.ellipse(x+xx*scale, y+yy*scale, 1.15*scale, fill="#A9CDDC", stroke=BLUE, sw=.4)


def model_glyph(s, x, y, conformer=False):
    """A larger graphic with uniform cells: no literal layer or attention counts."""
    start=len(s.items)
    for dx, dy, fill in ((0,0,"#EDF3E8"),(3,2,"#DDEADB"),(6,4,"#BED5BF")):
        s.rect(x+dx, y+dy, 15, 15, fill, "#7E9D83", .45, .8)
    for xx in (x+11, x+16):
        s.line([(xx,y+4),(xx,y+19)], "#94B399", .3)
    for yy in (y+9,y+14):
        s.line([(x+6,yy),(x+21,yy)], "#94B399", .3)
    s.rect(x+7,y+5,4,4,"#F5F7EC",GREEN,.4)
    if conformer:
        s.line([(x+22,y+12),(x+30,y+12)],GREEN,.55,True)
        for j, fill in enumerate(("#D8D0F0","#D1E3D1","#F4E7B9","#D2DCEB")):
            s.rect(x+31+j*5.3,y+7,3.8,12,fill,LAVENDER,.35,.6)
        s.line([(x+33,y+5),(x+33,y+2),(x+49,y+2),(x+49,y+5)],LAVENDER,.45)
        for xx in (x+38.3,x+43.6):
            s.line([(xx,y+2),(xx,y+5)],LAVENDER,.45)
    else:
        s.line([(x+22,y+12),(x+30,y+12)],GREEN,.55,True)
        for j in range(4):
            s.rect(x+31+j*5.3,y+7,3.8,12,"#CCE0CB",GREEN,.35,.6)
    # Wider symbolic processing path; not a change in architectural dimensions.
    for item in s.items[start:]:
        if "pts" in item:
            item["pts"]=[(x+(xx-x)*1.85, yy) for xx,yy in item["pts"]]
        else:
            item["x"]=x+(item["x"]-x)*1.85
            item["w"]*=1.85


def symbol(s, x, y, conformer=False):
    if not conformer:
        s.ellipse(x,y,2.2,fill=BLUE,stroke="none")
    else:
        col="#CE914F"
        s.items.append(dict(kind="polygon",pts=[(x,y-2.6),(x+2.6,y),(x,y+2.6),(x-2.6,y)],fill=col,stroke=col,sw=.2))


def protected_files():
    paths=[PAPER/p for p in ("main.pdf","main.tex","supplementary.pdf","supplementary.tex",
        "claim_registry.json","source_data_contract.json","submission_checks.md","frozen_decoder_specification.json",
        "tools/build_figure1_graphic_review.py","tools/verify_figure1_graphic_review.py","tools/build_figure1_reference_review.py","tools/build_figure1_icon_review.py","tools/verify_figure1_icon_review.py")]
    paths += [p for p in (PAPER/"figures").iterdir() if p.is_file()]
    paths += list((PAPER/"source_data").glob("*.csv"))
    paths += list((PAPER/"editable_figures").glob("*v13*"))
    for folder in ("figure1_v14_reference_review","figure1_v15_icon_review","figure1_v16_graphic_review"):
        paths += [p for p in (PAPER/"editable_figures"/folder).iterdir() if p.is_file()]
    return sorted(set(p for p in paths if p.is_file()))


def build():
    digest=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    before={p.relative_to(PAPER).as_posix():digest(p) for p in protected_files()}
    with (PAPER/"source_data/figure1_workflow.csv").open(encoding="utf-8-sig") as f:
        rows={r["node_id"]:r for r in csv.DictReader(f)}
    decoder=json.loads((PAPER/"frozen_decoder_specification.json").read_text(encoding="utf-8"))
    nd=rows["historical_discovery"]["n_participants"]
    nl=rows["locked_confirmation"]["n_participants"]
    np=rows["protected_external_test"]["n_participants"]
    nr=rows["protected_external_test"]["inference_units"]
    assert nr==str(decoder["full_register_units"])=="90"
    assert decoder["reported_raw_bn_units"]==30 and decoder["source_conditions"]==5
    assert len(decoder["seeds"])==3 and len(decoder["input"]["channels"])==8
    s=engine.Scene()
    s.rect(0,0,W,H,"#FFFFFF","none")
    s.text(5,17,"Access-conditioned deployment audit",10.5,INK,True)
    s.text(W-5,16,"Schematic glyphs",7,MUTED,align="right")
    main_start=len(s.items)
    s.panel(4,28,322,298,"a","Frozen inference & access","#9A939C")

    # Historical register is separate from the schematic raw-BN inference path.
    for x,title,count,note,fill,icon in (
        (13,"Discovery",f"4 cohorts · n={nd}","Probability-only","#FCF5D8",engine.archive),
        (117,"Locked",f"Dreyer · n={nl}","Prespecified test","#EAF1E8",engine.lock),
        (221,"Protected",f"Stieger · n={np}",f"{nr} registered units","#F0EBF8",engine.shield)):
        s.rect(x,53,96,44,fill,"none",radius=3)
        icon(s,x+10,60)
        s.text(x+29,67,title,8,INK,True)
        s.text(x+48,81,count,7.5,INK,align="center")
        s.text(x+48,91,note,7,MUTED,align="center")

    # Bigger EEG/model glyphs replace the long inference heading and empty cards.
    s.rect(14,110,55,75,"#F5F9FB","#C4D0D9",.55,3)
    s.text(41.5,121,"Target EEG",8,INK,True,"center")
    head(s,41.5,141,1.05)
    for yy,offset,col in ((162,0,BLUE),(170,3,"#799CBA"),(178,-2,"#82A79E")):
        pts=[(21,yy),(26,yy),(29,yy-1),(32,yy+2),(36,yy-3+offset*.3),
             (39,yy+2),(43,yy-1),(47,yy),(53,yy),(62,yy)]
        s.line(pts,col,.55)
    s.line([(69,148),(80,148),(80,128),(94,128)],MUTED,.65,True)
    s.line([(80,148),(80,169),(94,169)],MUTED,.65,True)
    s.ellipse(80,148,1.3,fill=MUTED,stroke="none")
    for yy,model,conformer in ((107,"EEGNet",False),(151,"EEG-Conformer",True)):
        color="#CE914F" if conformer else BLUE
        s.rect(94,yy,116,36,"#F2F7EF","#A6BCA4",.55,3)
        model_glyph(s,101,yy+13,conformer)
        symbol(s,103,yy+7,conformer)
        s.text(110,yy+9.5,model,8,INK,True)
        s.line([(210,yy+21),(224,yy+21)],color,.7,True)
        scores(s,224,yy+13,color,n=4)
        s.line([(246,yy+21),(265,yy+21)],color,.65,True)
    s.text(235,115,"Scores",7.5,MUTED,align="center")
    # Explicit repeated operation, never a fusion or ensemble.
    s.rect(265,107,52,80,"#FBFCFD","#C7D0D9",.5,3)
    for yy,conformer,col in ((128,False,BLUE),(172,True,"#CE914F")):
        symbol(s,275,yy,conformer)
        s.rect(283,yy-6,22,12,"#FFFFFF",col,.5,1)
        for dy in (-2,1,4): s.line([(287,yy+dy),(301,yy+dy)],col,.4)
    s.text(291,144,"Separate",7.5,INK,align="center")
    s.text(291,153,"audits",7.5,INK,align="center")
    engine.lock(s,48,193,BLUE,.75)
    s.text(61,200,"Frozen · no retraining / reselection",7.5,MUTED)
    # This is a policy-family fanout of the repeated audit, not a data merge.
    s.line([(291,187),(291,208),(61,208)],MUTED,.6)
    for cx,col in ((61,BLUE),(165,GRAY),(269,RED)):
        s.line([(cx,208),(cx,216)],col,.7,True)

    # Graphic-first access contracts, matched to the unchanged scientific taxonomy.
    for x,title,col,fill in ((13,"Non-anticipating",BLUE,engine.PALE_BLUE),
                            (117,"Complete batch",GRAY,engine.PALE_GRAY),
                            (221,"Label-informed",RED,engine.PALE_RED)):
        s.rect(x,217,96,80,fill,col,.6,3)
        s.text(x+48,229,title,8,col,True,"center")
    # Crossed target-label input at the fitting control, not at evaluation.
    engine.tag_outline(s,28,238,BLUE,1.7)
    s.line([(27,236),(48,254)],BLUE,1)
    s.line([(49,246),(63,246)],BLUE,.65)
    s.line([(61,241),(61,251)],BLUE,.9)
    slider(s,70,237,BLUE,.9)
    s.text(61,266,"No target labels in fit",7.5,INK,align="center")
    for xx,yy,ww,txt in ((18,271,42,"Source-only"),(62,271,42,"Prefix/suffix"),
                        (18,283,42,"Strict-past"),(62,283,42,"Session-fwd")):
        chip(s,xx,yy,ww,10,txt,BLUE,size=7)
    # Entire batch is visible to the fit; never label this online.
    scores(s,130,240,GRAY,stacked=True)
    s.line([(162,247),(176,247)],GRAY,.65,True)
    slider(s,180,237,GRAY,.9)
    s.text(165,266,"All target scores",7.5,INK,align="center")
    s.text(165,278,"Transductive upper bound",7.5,GRAY,align="center")
    chip(s,140,283,50,10,"Not online",GRAY,size=7)
    # Red oracle receives target scores AND labels; no winner symbol.
    scores(s,227,240,RED,n=3)
    engine.tag_outline(s,253,240,RED,1.25)
    s.text(249,250,"+",8,RED,align="center")
    s.line([(269,247),(277,247)],RED,.65,True)
    slider(s,281,237,RED,.9)
    s.text(269,266,"Scores + labels",7.5,INK,align="center")
    s.text(269,278,"Oracle diagnostic",7.5,RED,align="center")
    chip(s,235,283,68,10,"Not deployable",RED,size=7)
    s.text(165,308,"Compare within each access contract",7.5,MUTED,align="center")
    s.text(165,320,"Protected prefix: MIXED · below the 2-pp gate",7.5,RED,True,"center")
    tighten_main_column(s,main_start)

    # (b) The actual registered first-ten fit, then frozen suffix evaluation.
    s.panel(330,28,148.4,100,"b","Protected prefix protocol","#7E9B86")
    chip(s,342,53,46,12,"Raw-BN",GREEN,"#F1F5ED",7.5)
    s.text(418,61,"Freeze policy",7.5,MUTED,align="center")
    engine.lock(s,412,65,GREEN,.72)
    for j in range(10): s.rect(343+j*5.0,77,3.7,13,"#BEDAE6",BLUE,.4,.4)
    s.line([(393,83.5),(420,83.5)],GREEN,.75,True)
    for j in range(6): s.rect(424+j*5.0,77,3.7,13,"#D7E7D0",GREEN,.4,.4)
    s.text(457,87,"...",7.5,GREEN)
    s.text(367.5,101,"First 10: fit",7.5,BLUE,True,"center")
    s.text(443,101,"Suffix: test",7.5,GREEN,True,"center")
    s.text(367.5,115,"Unlabeled",7.5,MUTED,align="center")
    engine.tag_outline(s,403,108,GREEN,.85)
    s.text(416.5,115,"Labels: eval only",7.5,GREEN)

    # (c) No bar lengths or positive-only residuals: equation with short labels.
    s.panel(330,136,148.4,87,"c","Decision decomposition","#9585B4")
    for x,w,fill in ((342,29,"#EAF3F8"),(382,41,"#EDF3E9"),(434,32,"#F2EDF8")):
        s.rect(x,159,w,43,fill,"none",radius=3)
    math_terms(s,349,174,[("G",False,BLUE),("A",True,BLUE)])
    s.text(376.5,174,"=",10.5,INK,align="center")
    math_terms(s,385,174,[("L",False,GREEN),("decision",True,GREEN)])
    s.text(428.5,174,"−",10.5,INK,align="center")
    math_terms(s,444,174,[("L",False,LAVENDER),("A",True,LAVENDER)])
    for cx,first,last,col in ((356.5,"BA","gain",BLUE),(402.5,"Default","loss",GREEN),
                              (450,"Signed","residual",LAVENDER)):
        s.text(cx,188,first,7.5,col,align="center")
        s.text(cx,198,last,7.5,col,align="center")
    s.text(342,215,"Same trials · label-informed oracle",7,MUTED)

    # (d) Actual 5-by-3 factors and participant aggregation, not observations.
    s.panel(330,231,148.4,95,"d","Participant summary","#89929F")
    s.text(404.2,257,"Within each backbone",7.5,MUTED,align="center")
    for r in range(5):
        for c in range(3):
            s.rect(346+c*7,262+r*4.6,5.8,3.7,
                   ("#BFD7E2","#D8D0EE","#CDE1CC")[c],"#98ACB4",.3,.3)
    s.line([(369,274),(390,274)],MUTED,.65,True)
    engine.person(s,400,264,GRAY,1.15)
    s.line([(410,274),(427,274)],MUTED,.65,True)
    for x,y in ((437,265),(448,262),(459,265)):
        engine.person(s,x,y,GRAY,.8)
    s.text(356,294,"5 conditions",7.5,INK,align="center")
    s.text(356,304,"× 3 seeds",7.5,INK,align="center")
    s.text(400,294,"Participant",7.5,INK,align="center")
    s.text(400,304,"mean",7.5,INK,align="center")
    s.text(448,294,f"{np} participants",7.5,INK,align="center")
    s.text(448,304,"Summary",7.5,INK,align="center")
    s.text(404.2,318,"Raw-BN: 30 of 90 registered units",7,MUTED,align="center")

    refresh_text_boxes(s)
    spec=s.export()
    # Raster previews are rendered from the vector PDF, not separately authored.
    subprocess.run(["pdftoppm","-png","-singlefile","-r","600",str(OUT/(STEM+".pdf")),str(OUT/STEM)],check=True,capture_output=True)
    subprocess.run(["pdftoppm","-png","-singlefile","-scale-to","1800",str(OUT/(STEM+".pdf")),str(OUT/"preview")],check=True,capture_output=True)
    subprocess.run(["pdftoppm","-gray","-png","-singlefile","-r","120",str(OUT/(STEM+".pdf")),str(OUT/"preview_grayscale")],check=True,capture_output=True)
    beforetext=json.loads((PAPER/"editable_figures/figure1_v16_graphic_review/figure1_acdd_workflow_v16_graphic_review_qa.json").read_text(encoding="utf-8"))["text_boxes"]
    word_count=lambda texts: len(re.findall(r"[A-Za-z0-9]+(?:[-/][A-Za-z0-9]+)*", " ".join(t["text"] for t in texts)))
    old_words,new_words=word_count(beforetext),word_count(s.text_boxes)
    after={name:digest(PAPER/name) for name in before}
    assert before==after,"Protected manuscript, source, or prior review changed"
    qa=dict(status="rendered_visual_review_pending",scope="Independent v17 only; no manuscript replacement",
        dimensions_inches=[W/72,H/72],minimum_font_pt=min(t["size"] for t in s.text_boxes),
        text_count=len(s.text_boxes),text_boxes=s.text_boxes,
        word_count_definition="Latin/alphanumeric tokens including within-token hyphens and slashes; math runs counted separately",
        words_v16=old_words,words_v17=new_words,
        type_sizes_v16=sorted(set(t["size"] for t in beforetext)),
        type_sizes_v17=sorted(set(t["size"] for t in s.text_boxes)),
        text_tokens_unchanged=sorted(re.findall(r"[A-Za-z0-9]+(?:[-/][A-Za-z0-9]+)*"," ".join(t["text"] for t in beforetext)))==sorted(re.findall(r"[A-Za-z0-9]+(?:[-/][A-Za-z0-9]+)*"," ".join(t["text"] for t in s.text_boxes))),
        native_shapes=len(spec["pages"][0]["shapes"]),native_connectors=len(spec["pages"][0]["connectors"]),
        native_visio_status="not_generated; previous native automation approval limit remains unresolved",
        preserved_file_count=len(before),preserved_sha256=before,
        scientific_boundaries=["Parallel frozen backbones, no fusion, retraining or reselection",
            "No target labels in deployable fit; evaluation labels explicitly permitted",
            "Source-only, prefix/suffix, strict-past, session-forward are alternatives, not a sequence",
            "Complete batch is a transductive upper bound, not online",
            "Oracle is label-informed and not deployable; residual is signed on same trials",
            "Protected raw-BN first-ten-to-suffix; MIXED below 2-pp gate",
            "5 conditions by 3 seeds per participant within each backbone; 30 raw-BN of 90 units",
            "All token sizes, EEG traces, model glyphs and threshold controls are schematic"])
    (OUT/(STEM+"_qa.json")).write_text(json.dumps(qa,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in qa.items() if k not in ("text_boxes","preserved_sha256")},indent=2))


if __name__=="__main__":
    build()
