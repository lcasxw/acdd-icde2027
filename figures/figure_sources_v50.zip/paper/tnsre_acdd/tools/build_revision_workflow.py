"""Revise workflow terminology while preserving the v19 drawing geometry."""
from contextlib import redirect_stdout
import hashlib
import io
import json
import xml.etree.ElementTree as ET

import build_figure1_micro_refinement as workflow

PAPER = workflow.PAPER
OUT = PAPER / "editable_figures/figure1_revision_v49_20261014"
STEM = "figure1_acdd_workflow_v49"
CHANGES = {"Transductive upper bound": "Transductive reference"}


class RevisionScene(workflow.MicroScene):
    def export(self):
        found = []
        for item in self.items:
            if item.get("kind") == "text" and item["text"] in CHANGES:
                found.append(item["text"])
                item["text"] = CHANGES[item["text"]]
        assert set(found) == set(CHANGES), found
        return super().export()


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    base, engine = workflow.base, workflow.engine
    saved = (base.OUT, base.STEM, engine.OUT, engine.STEM, engine.Scene)
    base.OUT = engine.OUT = OUT
    base.STEM = engine.STEM = STEM
    engine.Scene = RevisionScene
    try:
        with redirect_stdout(io.StringIO()):
            base.build()
    finally:
        base.OUT, base.STEM, engine.OUT, engine.STEM, engine.Scene = saved
    old = list(ET.parse(workflow.OUT / (workflow.STEM + ".svg")).getroot())
    new = list(ET.parse(OUT / (STEM + ".svg")).getroot())
    assert len(old) == len(new)
    edits = []
    for before, after in zip(old, new):
        assert before.tag == after.tag
        assert before.attrib == after.attrib, (before.attrib, after.attrib)
        if before.text != after.text:
            assert CHANGES.get(before.text) == after.text
            edits.append([before.text, after.text])
    assert len(edits) == len(CHANGES)
    path = OUT / (STEM + "_qa.json")
    qa = json.loads(path.read_text(encoding="utf-8"))
    for key in ("words_v16", "words_v17", "type_sizes_v16", "type_sizes_v17", "text_tokens_unchanged"):
        qa.pop(key, None)
    qa.update(scope="v49 terminology correction; v19 coordinates, frames and drawing objects unchanged",
              text_edits=edits, geometry_identical_to_v19=True, visual_review="pending",
              scientific_reason="Complete target-score access does not imply a mathematical performance upper bound.")
    qa["scientific_boundaries"] = [s.replace("transductive upper bound", "transductive reference")
                                    for s in qa["scientific_boundaries"]]
    qa["output_sha256"] = {ext: hashlib.sha256((OUT / (STEM + ext)).read_bytes()).hexdigest()
                            for ext in (".pdf", ".svg", ".png")}
    path.write_text(json.dumps(qa, indent=2), encoding="utf-8")
    print(json.dumps({"text_edits": edits, "geometry_identical_to_v19": True, "output": str(OUT)}))


if __name__ == "__main__":
    build()
