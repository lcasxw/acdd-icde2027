"""Independent v18 finishing pass: exactly four frames and one inlet arrow.

Reuse the unchanged v17 authoring source and v15 renderer. The local subclass
changes only panel-frame styling and the identified Conformer inlet path.
No manuscript, previous review, scientific source, text, or font is edited.
"""
from contextlib import redirect_stdout
import hashlib
import io
import json
import xml.etree.ElementTree as ET

import build_figure1_typography_review as base

PAPER=base.PAPER
OUT=PAPER/"editable_figures/figure1_v18_finish_review"
STEM="figure1_acdd_workflow_v18_finish_review"
PRIOR=PAPER/"editable_figures/figure1_v17_typography_review"
PRIOR_STEM="figure1_acdd_workflow_v17_typography_review"
OriginalScene=base.engine.Scene


def soften(color):
    """Ten-percent white mix, only for outer frames, without transparency."""
    return "#"+"".join(f"{round(int(color[i:i+2],16)*.9+255*.1):02X}" for i in (1,3,5))


class FinishScene(OriginalScene):
    def __init__(self):
        super().__init__()
        self.frame_changes=[]
        self.inlet_changes=0

    def panel(self,x,y,w,h,number,title,accent):
        first=len(self.items)
        super().panel(x,y,w,h,number,title,accent)
        frame=self.items[first]
        assert frame["kind"]=="rect" and frame["dash"] and frame["sw"]==.65
        frame.update(sw=.45,stroke=soften(accent))
        self.frame_changes.append(dict(panel=number,from_color=accent,to_color=frame["stroke"],
                                       from_width_pt=.65,to_width_pt=.45))

    def line(self,pts,color=base.INK,sw=.65,arrow=False,dash=False):
        if pts==[(80,148),(80,169),(94,169)]:
            assert arrow and not dash and color==base.MUTED
            pts=[(80,148),(80,172),(94,172)]
            self.inlet_changes+=1
        return super().line(pts,color,sw,arrow,dash)

    def export(self):
        assert [v["panel"] for v in self.frame_changes]==list("abcd")
        assert self.inlet_changes==1
        return super().export()


def compare_vectors():
    old=list(ET.parse(PRIOR/(PRIOR_STEM+".svg")).getroot())
    new=list(ET.parse(OUT/(STEM+".svg")).getroot())
    assert len(old)==len(new)
    changed=[]
    for idx,(a,b) in enumerate(zip(old,new)):
        assert a.tag==b.tag and a.text==b.text
        if a.attrib==b.attrib: continue
        kind=a.tag.rsplit("}",1)[-1]
        keys={k for k in set(a.attrib)|set(b.attrib) if a.get(k)!=b.get(k)}
        if kind=="rect":
            assert keys=={"stroke","stroke-width"}
            assert a.get("stroke-dasharray")=="3.2 2.5"
            assert a.get("stroke-width")=="0.65" and b.get("stroke-width")=="0.45"
            assert b.get("stroke")==soften(a.get("stroke"))
        else:
            assert kind in ("polyline","polygon") and keys=={"points"}
            ap=[tuple(map(float,v.split(","))) for v in a.get("points").split()]
            bp=[tuple(map(float,v.split(","))) for v in b.get("points").split()]
            assert len(ap)==len(bp)==3
            assert all(abs(x[0]-y[0])<1e-8 for x,y in zip(ap,bp))
            expected=[0,3,3] if kind=="polyline" else [3,3,3]
            assert all(abs(y[1]-x[1]-dy)<1e-8 for x,y,dy in zip(ap,bp,expected))
        changed.append(dict(element_index=idx,kind=kind,changed_attributes=sorted(keys),before=a.attrib,after=b.attrib))
    assert [d["kind"] for d in changed].count("rect")==4
    assert [d["kind"] for d in changed].count("polyline")==1
    assert [d["kind"] for d in changed].count("polygon")==1
    return changed


def build():
    old_paths=(base.OUT,base.STEM,base.engine.OUT,base.engine.STEM)
    old_protected=base.protected_files
    extra=list(PRIOR.iterdir())+[PAPER/"tools/build_figure1_typography_review.py",
                                PAPER/"tools/verify_figure1_typography_review.py"]
    base.protected_files=lambda:sorted(set(old_protected()+[p for p in extra if p.is_file()]))
    base.OUT,base.STEM,base.engine.OUT,base.engine.STEM=OUT,STEM,OUT,STEM
    base.engine.Scene=FinishScene
    try:
        # v17's output is intermediate diagnostics; this runner reports v18 below.
        with redirect_stdout(io.StringIO()):
            base.build()
    finally:
        base.OUT,base.STEM,base.engine.OUT,base.engine.STEM=old_paths
        base.protected_files=old_protected
        base.engine.Scene=OriginalScene

    qa_path=OUT/(STEM+"_qa.json")
    qa=json.loads(qa_path.read_text(encoding="utf-8"))
    prior=json.loads((PRIOR/(PRIOR_STEM+"_qa.json")).read_text(encoding="utf-8"))
    assert qa["text_boxes"]==prior["text_boxes"],"Text style or position changed"
    changes=compare_vectors()
    qa.update(scope="Independent v18 only; no manuscript or prior-review replacement",
              reference_version="v17",text_and_positions_identical_to_v17=True,
              frame_width_pt=.45,frame_white_mix=.1,conformer_inlet_y_pt=172,
              conformer_outlet_y_pt=172,svg_changes=changes,
              visual_review="current_color_and_grayscale_pending")
    # Drop the v17 generator's historical typography-comparison names.
    for key in ("words_v16","words_v17","type_sizes_v16","type_sizes_v17"):
        qa.pop(key,None)
    qa.update(word_count=prior["words_v17"],type_sizes=prior["type_sizes_v17"])
    for name,sha in qa["preserved_sha256"].items():
        assert hashlib.sha256((PAPER/name).read_bytes()).hexdigest()==sha
    qa_path.write_text(json.dumps(qa,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in qa.items() if k not in ("text_boxes","preserved_sha256","svg_changes")},indent=2))


if __name__=="__main__":
    build()
