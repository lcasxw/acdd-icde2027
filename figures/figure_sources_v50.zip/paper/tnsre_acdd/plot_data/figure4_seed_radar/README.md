# Figure 4: seed-resolved source-omission radar inputs

This is a deterministic reaggregation of frozen raw-BN target-prior-quantile
results at the protected prefix-10-to-suffix endpoint. The scientific branch
remains mixed. No training, policy fit, bootstrap, or new confidence interval is
performed. No participant is removed, and no future scores or target labels are
available to the original deployable policy fit.

For each backbone, omitted source condition, seed, and participant, average the
four retained source-condition BA gains. Then average the same 62 participant
means to obtain the seed contour. The arithmetic mean over seeds 17, 29, and 43
reconstructs every original frozen omission mean to within 1e-12 BA. The thick
mean contour uses the copied frozen mean, not a replacement estimate.

- participant_long.csv: 1,860 participant/seed/omission/backbone rows, with four
  source line references per row; these are not 1,860 independent participants.
- seed_summary.csv: 30 descriptive seed-specific cohort means.
- frozen_mean_summary.csv: ten original mean strings plus reconstruction checks.
- qa_report.json: frozen input hashes, coverage, negative means and output hashes.

Fixed spoke order is BNCI2014-001, Cho2017, Lee2019-MI, PhysioNetMI, LODO. Each
spoke names the omitted training condition; all evaluation uses Stieger2021.
Both backbone panels use true BA gain in percentage points on one -1 to 5 pp
scale, with an explicit zero ring. Preserve the two negative seed means. Seed
contours are descriptive training-seed sensitivity, not confidence intervals;
the overlapping omission groups are not independent cohorts. Polygon area is
not an outcome, and mean positivity does not imply universal participant benefit.

Rebuild with the standard-library-only module:

    python paper/tnsre_acdd/tools/radar_seed_data.py --repo-root .

An independent runner can choose --output-dir without changing output bytes.
