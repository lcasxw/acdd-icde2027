"""Rebuild the approved Figure 7 from frozen sources into a separate output directory."""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ARCHIVE = Path(__file__).resolve().parent
OUT = ARCHIVE
PAPER = ARCHIVE.parents[1]
SOURCE = PAPER / 'source_data'
REPO = PAPER.parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(REPO / '.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
import numpy as np
sys.path.insert(0, str(PAPER / 'tools'))
from plot_style import MODEL_COLORS

W, H = 86.8, 120.0
STEM = 'figure7_single_column'
MODELS = ('eegnet', 'eeg_conformer')
LABELS = {'eegnet': 'EEGNet', 'eeg_conformer': 'EEG-Conformer'}
MARKERS = {'eegnet': 'o', 'eeg_conformer': 'D'}
INK, MUTED, AXIS, GRID = '#263746', '#657580', '#9CA9B3', '#E7ECF0'
FIELDS = ('mean_gain', 'ci_lower', 'ci_upper')
SOURCES = ('figure5_participant_gain.csv', 'review_harm_quartiles.csv',
           'review_quartile_membership.csv', 'figure5_harm_rates.csv')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def read(name):
    with (SOURCE / name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
def write_csv(name, rows):
    with (OUT / name).open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
def protected_hashes():
    return {name: sha(SOURCE / name) for name in SOURCES}

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    baseline = protected_hashes()
    style = ARCHIVE / 'ccfa_paper.mplstyle'
    plt.style.use(style)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'pdf.fonttype': 42, 'svg.fonttype': 'none', 'svg.hashsalt': 'figure7-single-column-20261007',
        'path.simplify': False, 'savefig.bbox': None, 'savefig.pad_inches': 0})
    participants, quartiles, members, harms = map(read, SOURCES)
    qdata = {(r['backbone'], r['stratifier'], int(r['quartile'])): r for r in quartiles}
    assert len(qdata) == len(quartiles) == 16
    harm = {r['backbone']: r for r in harms}
    values = {}; summaries = {}; degradation = []
    for model in MODELS:
        selected = [r for r in participants if r['backbone'] == model]
        assert len(selected) == len({r['participant_id'] for r in selected}) == 62
        assert all(r['method'] == 'target_prior_quantile' and r['endpoint'] == 'prefix_suffix'
                   and r['analysis_variant'] == 'main' and int(r['n_protocols']) == 5
                   and int(r['n_seeds']) == 3 for r in selected)
        values[model] = np.array([float(r['participant_mean_gain']) * 100 for r in selected])
        v = values[model]
        assert v.min() > -4 and v.max() < 8
        assert abs(v.mean() - 100 * float(harm[model]['mean_gain'])) < 1e-12
        summaries[model] = {'n': 62, 'mean_pp': float(v.mean()), 'median_pp': float(np.median(v)),
                            'minimum_pp': float(v.min()), 'maximum_pp': float(v.max())}
        for event, threshold in (('any_negative', 0), ('gt_2pp', -2)):
            field = 'participant_harm_' + event
            rate = float(harm[model][field]); count = int((v < threshold).sum())
            assert count == round(rate * 62)
            degradation.append({'model': model, 'event': event, 'threshold_pp': threshold,
                'n': count, 'N': 62, 'rate_pct': rate * 100,
                'ci_lower_pct': float(harm[model][field + '_ci_lower']) * 100,
                'ci_upper_pct': float(harm[model][field + '_ci_upper']) * 100})
        for stratifier in ('decision_loss', 'auc'):
            ids = []
            for q in range(1, 5):
                selected = [r for r in members if r['backbone'] == model
                            and r['stratifier'] == stratifier and int(r['quartile']) == q]
                ref = qdata[model, stratifier, q]
                assert len(selected) == int(ref['n_participants']) == (16 if q in (1, 4) else 15)
                assert abs(np.mean([float(r['gain']) for r in selected]) - float(ref['mean_gain'])) < 1e-12
                ids.extend(r['participant_id'] for r in selected)
            assert len(ids) == len(set(ids)) == 62
    rare = [r for r in degradation if r['event'] == 'gt_2pp']
    assert all(tuple(r[k] for k in ('n', 'N', 'rate_pct', 'ci_lower_pct', 'ci_upper_pct')) ==
               tuple(rare[0][k] for k in ('n', 'N', 'rate_pct', 'ci_lower_pct', 'ci_upper_pct')) for r in rare)

    fig = plt.figure(figsize=(W / 25.4, H / 25.4), dpi=240)
    ax = fig.add_axes([0, 0, 1, 1], xlim=(0, W), ylim=(0, H))
    ax.set_axis_off()
    def text(x, y, s, size=8, color=INK, ha='left', weight='normal', rotation=0, gid=None):
        item = ax.text(x, y, s, fontsize=size, color=color, ha=ha, va='center',
                       fontweight=weight, rotation=rotation, zorder=10)
        if gid: item.set_gid(gid)
        return item
    def line(x, y, color=AXIS, lw=.55, zorder=1, gid=None, **kwargs):
        item, = ax.plot(x, y, color=color, lw=lw, zorder=zorder,
                        solid_capstyle='butt', dash_capstyle='butt', **kwargs)
        if gid: item.set_gid(gid)
        return item
    def point(x, y, model, size=3.0, gid=None):
        item, = ax.plot([x], [y], marker=MARKERS[model], markersize=size,
            linestyle='none', markerfacecolor=MODEL_COLORS[model], markeredgewidth=0,
            color=MODEL_COLORS[model], zorder=5)
        if gid: item.set_gid(gid)
        return item

    # One legend communicates model identity across both panels and mean columns.
    for x, model in ((11.0, MODELS[0]), (43.5, MODELS[1])):
        line([x - 3, x + 3], [117.0] * 2, color=MODEL_COLORS[model], lw=1.15,
             ls='-' if model == 'eegnet' else (0, (3, 1.5)))
        point(x, 117.0, model, 3.2)
        text(x + 4.5, 117.0, LABELS[model], size=8)
    text(2.0, 111.7, '(a)  Participant gains', size=8.8, weight='bold')
    text(84.0, 111.7, 'n=62/model', size=7.5, color=MUTED, ha='right')

    # ECDF uses all 62 original values; sorted ranks are not cross-model pairings.
    ex0, ex1, ey0, ey1 = 13.0, 84.0, 83.0, 107.8
    def ex(gain): return ex0 + (np.asarray(gain) + 4) / 12 * (ex1 - ex0)
    def ey(percent): return ey0 + np.asarray(percent) / 100 * (ey1 - ey0)
    for y, label in ((0, '0'), (50, '50'), (100, '100')):
        if y: line([ex0, ex1], [ey(y)] * 2, color=GRID, lw=.45)
        line([ex0 - .8, ex0], [ey(y)] * 2)
        text(ex0 - 1.8, ey(y), label, size=7.5, ha='right')
    line([ex0, ex0], [ey0, ey1], lw=.6)
    line([ex0, ex1], [ey0, ey0], lw=.6)
    line([ex(0)] * 2, [ey0, ey1], color=AXIS, lw=.7, ls=(0, (2.7, 2.5)))
    for x in (-4, -2, 0, 2, 4, 6, 8):
        line([ex(x)] * 2, [ey0, ey0 - .8])
        text(ex(x), 80.25, str(x).replace('-', '−'), size=7.5, ha='center')
    text(3.0, (ey0 + ey1) / 2, 'Cumulative (%)', size=8, ha='center', rotation=90)
    text((ex0 + ex1) / 2, 76.9, 'BA gain (pp)', size=8, ha='center')
    ecdf_rows = []; ecdf_geometry = []
    for model in MODELS:
        v = np.sort(values[model]); p = np.arange(1, 63) / 62 * 100
        xdata = np.r_[-4, v, 8]; ydata = np.r_[0, p, 100]
        curve = line(ex(xdata), ey(ydata), color=MODEL_COLORS[model], lw=1.15,
            ls='-' if model == 'eegnet' else (0, (3, 1.5)), drawstyle='steps-post',
            zorder=3, gid='ecdf-' + model)
        assert np.max(np.abs((curve.get_xdata() - ex0) / (ex1-ex0) * 12 - 4 - xdata)) < 1e-12
        for i, (gain, cumulative) in enumerate(zip(v, p), 1):
            ecdf_rows.append({'model': model, 'rank': i, 'gain_pp': gain, 'cumulative_pct': cumulative})
        ecdf_geometry.append({'model': model, 'x_gain_pp': list(xdata),
            'y_cumulative_pct': list(ydata), 'x_mm': list(curve.get_xdata()), 'y_mm': list(curve.get_ydata())})
    text(15.0, 103.7, 'Gain < 0', size=7.5, color=MUTED)
    for y, model in ((99.4, MODELS[0]), (95.2, MODELS[1])):
        point(16.0, y, model, 3.1)
        p = 100 * np.mean(values[model] < 0)
        text(19.3, y, f'{p:.1f}%', size=8)

    # Quartile intervals: both blocks share the same linear gain scale.
    text(2.0, 72.2, '(b)  Quartile gains (95% CI)', size=8.8, weight='bold')
    bx0, bx1, blo, bhi = 13.0, 60.5, -1.2, 5.0
    def bx(gain): return bx0 + (np.asarray(gain) - blo) / (bhi - blo) * (bx1 - bx0)
    mean_right = {'eegnet': 70.1, 'eeg_conformer': 83.0}
    text(72.5, 68.2, 'Mean (pp)', size=7.5, color=MUTED, ha='center')
    point(61.8, 65.2, MODELS[0], 3.2)
    text(63.6, 65.2, 'Net', size=7.5, color=MUTED)
    point(74.2, 65.2, MODELS[1], 3.2)
    text(76.0, 65.2, 'Conf.', size=7.5, color=MUTED)
    estimates = []; geometry = []
    for stratifier, title, title_y, centers in (
        ('decision_loss', 'Decision loss', 68.2, [61.8, 57.4, 53.0, 48.6]),
        ('auc', 'Raw-logit AUC', 44.0, [39.5, 35.1, 30.7, 26.3])):
        text(13.0, title_y, title, size=8, color=MUTED)
        for tick in (-1, 0, 2, 4):
            line([bx(tick)] * 2, [min(centers)-1.65, max(centers)+1.65],
                 color=AXIS if tick == 0 else GRID, lw=.65 if tick == 0 else .4,
                 ls=(0, (2.7, 2.5)) if tick == 0 else '-')
        for quartile, center in zip((4, 3, 2, 1), centers):
            text(9.0, center, f'Q{quartile}', size=8, ha='right')
            for model, offset in ((MODELS[0], .78), (MODELS[1], -.78)):
                ref = qdata[model, stratifier, quartile]
                mean, lo, hi = (float(ref[f]) * 100 for f in FIELDS)
                assert blo <= lo <= mean <= hi <= bhi
                y = center + offset
                gid = f'{stratifier}-{model}-q{quartile}'
                ci = line([bx(lo), bx(hi)], [y] * 2, color=MODEL_COLORS[model], lw=.9,
                          zorder=3, gid='ci-' + gid)
                for endpoint, label in ((lo, 'lower'), (hi, 'upper')):
                    line([bx(endpoint)] * 2, [y-.40, y+.40], color=MODEL_COLORS[model],
                         lw=.65, zorder=3, gid=label + '-' + gid)
                marker = point(bx(mean), y, model, 3.1, gid='mean-' + gid)
                text(mean_right[model], center, f'{mean:+.2f}'.replace('-', '−'),
                     size=8, ha='right', gid='value-' + gid)
                assert np.max(np.abs((ci.get_xdata()-bx0)/(bx1-bx0)*(bhi-blo)+blo-[lo,hi])) < 1e-12
                record = {'model': model, 'stratifier': stratifier, 'quartile': quartile,
                    'n_participants': int(ref['n_participants']), 'mean_pp': mean,
                    'ci_lower_pp': lo, 'ci_upper_pp': hi}
                estimates.append(record)
                geometry.append({**record, 'ci_x_mm': list(ci.get_xdata()),
                    'mean_x_mm': float(marker.get_xdata()[0]), 'y_mm': y,
                    'mean_text_right_mm': mean_right[model], 'mean_text_y_mm': center})
    axis_y = 23.65
    line([bx0, bx1], [axis_y] * 2, lw=.6)
    for tick in (-1, 0, 2, 4):
        line([bx(tick)] * 2, [axis_y, axis_y-.8])
        text(bx(tick), 20.9, str(tick).replace('-', '−'), size=7.5, ha='center')
    text((bx0+bx1)/2, 17.7, 'BA gain (pp)', size=8, ha='center')

    # Both rare-degradation summaries are identical but retain separate N=62.
    line([2.0, 84.5], [15.0] * 2, color=GRID, lw=.6)
    text(2.0, 12.6, 'Decrease: n/N (%) [95% CI, %]', size=7.5, color=MUTED)
    for y, model in ((9.2, MODELS[0]), (5.9, MODELS[1])):
        r = next(r for r in degradation if r['model'] == model and r['event'] == 'any_negative')
        text(2.0, y, LABELS[model] + ', any', size=7.5)
        s = f"{r['n']}/{r['N']} ({r['rate_pct']:.1f}%) [{r['ci_lower_pct']:.1f}, {r['ci_upper_pct']:.1f}]"
        text(84.0, y, s, size=7.5, ha='right')
    r = rare[0]
    text(2.0, 2.5, 'Each model, >2 pp', size=7.5)
    text(84.0, 2.5, f"{r['n']}/{r['N']} ({r['rate_pct']:.1f}%) [{r['ci_lower_pct']:.1f}, {r['ci_upper_pct']:.1f}]", size=7.5, ha='right')

    fig.canvas.draw(); renderer = fig.canvas.get_renderer()
    boxes = []; outside = []; overlaps = []
    for item in fig.findobj(Text):
        if not item.get_visible() or not item.get_text().strip(): continue
        box = item.get_window_extent(renderer)
        if not box.width or not box.height: continue
        if box.x0 < -.5 or box.y0 < -.5 or box.x1 > fig.bbox.width+.5 or box.y1 > fig.bbox.height+.5:
            outside.append(item.get_text())
        boxes.append((item, box))
    for i, (item, box) in enumerate(boxes):
        for other, other_box in boxes[i+1:]:
            if box.overlaps(other_box): overlaps.append([item.get_text(), other.get_text()])
    diagnostics = {'outside': outside, 'text_overlaps': overlaps,
                   'minimum_font_pt': min(item.get_fontsize() for item, _ in boxes)}
    dump('layout_diagnostics.json', diagnostics)
    stamp = datetime(2026, 10, 7, tzinfo=timezone.utc)
    common = {'bbox_inches': None, 'pad_inches': 0, 'facecolor': 'white'}
    fig.savefig(OUT / f'{STEM}.pdf', metadata={'Title': 'Participant heterogeneity in prior-quantile gain',
        'Author': '', 'Creator': 'Source-exact scientific plotting', 'CreationDate': stamp, 'ModDate': stamp}, **common)
    fig.savefig(OUT / f'{STEM}.svg', metadata={'Title': STEM, 'Date': '2026-10-07'}, **common)
    fig.savefig(OUT / f'{STEM}.png', dpi=600, **common)
    fig.savefig(OUT / 'preview.png', dpi=240, **common)
    plt.close(fig)
    assert not outside and not overlaps, diagnostics
    assert baseline == protected_hashes()
    dump('baseline_hashes.json', baseline)
    dump('source_sha256.json', {name: sha(SOURCE/name) for name in SOURCES})
    write_csv('ecdf_points.csv', ecdf_rows)
    write_csv('quartile_estimates.csv', estimates)
    write_csv('degradation_estimates.csv', degradation)
    dump('artist_geometry.json', geometry)
    dump('ecdf_geometry.json', ecdf_geometry)
    dump('participant_summaries.json', summaries)
    dump('source_and_geometry_qa.json', {'status': 'automated_checks_passed',
        'size_mm': [W, H], 'participants_per_model': 62, 'participant_records': 124,
        'original_quartile_mean_ci_triples': 16, 'degradation_rate_ci_triples': 4,
        'minimum_font_pt': diagnostics['minimum_font_pt'], 'upper_range_pp': [-4, 8],
        'lower_range_pp': [blo, bhi], 'ci_x_limits_mm': [bx0, bx1],
        'source_estimates_recomputed': False, 'frozen_membership_means_verified': True,
        'rare_degradation_rows_combined_only_after_exact_equality_check': True,
        'protected_files_unchanged': len(baseline), 'visual_review': 'pending'})
    dump('manifest.json', {'chart_type': 'empirical cumulative distributions and grouped horizontal dot intervals',
        'x_categories_ordered': True, 'additive': False, 'uncertainty_present': True,
        'uncertainty_label': 'participant-bootstrap 95% CI conditional on fixed quartile memberships',
        'statistical_unit': 'participant after averaging three frozen seeds and five source conditions',
        'paired_data': False, 'pairing_preserved': True, 'legend_count': 1,
        'panel_count': 2, 'series_count': 2, 'minimum_font_pt': 7.5,
        'final_width_in': W/25.4, 'export_formats': ['pdf', 'svg', 'png'],
        'raster_dpi': 600, 'color_redundancy': True, 'final_size_checked': False,
        'palette_hex': MODEL_COLORS,
        'notes': 'ECDF on [-4,8] pp, conditional means on [-1.2,5] pp. Quartiles separately defined; no paired connectors. Mean columns Net/Conf. and circle/diamond symbols match EEGNet/EEG-Conformer. No density or clinical-harm encoding.'})
    dump('design_request.json', {'question': 'How do participant gain distributions and conditional quartile means reveal heterogeneity?',
        'domain': 'motor imagery EEG', 'models': 2, 'metrics': 1, 'panels': 2,
        'chart_family': 'empirical cumulative distribution and aligned dot intervals',
        'data_relation': 'participant distributions and conditional ordered quartile summaries',
        'ordered_x': True, 'distribution': True, 'paired': False, 'mixed_relations': True,
        'uncertainty': True, 'additive': False, 'notes': 'Author-selected single-column layout. Preserve 124 values, 16 frozen conditional mean/CI triples, and four degradation-rate intervals. Preview only.'})
    dump('palette.json', MODEL_COLORS)
    caption = ('Participant heterogeneity at the protected prefix-10-to-suffix endpoint (62 participants per model, '
        'after averaging three seeds and five frozen source conditions within participant). Gains are prior-quantile BA '
        'minus default zero-logit BA on the same suffix. (a) Exact ECDFs; annotations report gain <0. Mean/median gains '
        'are 1.41/1.19 pp for EEGNet and 1.75/1.62 for EEG-Conformer. (b) Means and original participant-bootstrap 95% CIs, '
        'grouped by decision-loss or raw-logit AUC quartiles. For display, EEGNet is vertically offset above EEG-Conformer within each row; mean columns '
        'Net and Conf. denote EEGNet and EEG-Conformer. Q1 and Q4 are the lowest and highest stratifier quartiles; n=16,15,15,16 from Q1 to Q4. Memberships are defined separately by '
        'model and stratifier; intervals condition on those memberships. Same-named quartiles are not paired, and participants '
        'recur across stratifications. Footer intervals describe degradation rates; each model retains its own denominator. '
        'Strata did not guide policy fitting. Degradation denotes performance loss.')
    (OUT/'caption.txt').write_text(caption+'\n',encoding='utf-8')
    (OUT/'README.md').write_text('''# Figure 7 single-column preview — 2026-10-07

Author-selected two-panel layout: exact participant ECDFs above two separately
defined quartile blocks sharing one gain scale. Native size 86.8 x 120 mm;
minimum text 7.5 pt. Model colors match the manuscript. The blue circle/Net
and orange diamond/Conf. label the two mean columns; numerical text uses dark ink.

Micro-polish: participant count on the existing panel-a heading row; shorter,
lighter stratifier headings; explicit model names and units over mean columns;
all three degradation summaries aligned on the same right edge. The prior
preview is preserved in `history/before_micro_polish_20261007`.

The 124 participant gains, 16 conditional mean/CI triples and four degradation
rate/CI summaries are retained. The two identical >2 pp summaries share a
display row labelled “each model”, preserving separate N=62 denominators.
No smoothing, CI recomputation, reselection or policy fitting is performed.
The protected branch remains mixed with its original 2-pp magnitude gate.

`caption.txt` includes the mean/median values and quartile group sizes moved
out of the plot. CSVs retain full precision; PDF/SVG are vector, PNG is 600 dpi.
`baseline_hashes.json` protects source CSVs, manuscript and publication assets.
This is a separate rendering. The approved archive and manuscript are not overwritten.

Rebuild with the archived script using --output and optionally --source. Compare exports with the approved archive.
Actual PDF color/grayscale renders require visual inspection after rebuilding.
''', encoding='utf-8')
    print(json.dumps({'output': str(OUT), 'size_mm': [W, H], **diagnostics}))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--source', type=Path, default=SOURCE)
    args = parser.parse_args()
    OUT, SOURCE = args.output.resolve(), args.source.resolve()
    if OUT == ARCHIVE.resolve() or ARCHIVE.resolve() in OUT.parents:
        raise ValueError('Rebuild output must be separate from the frozen approved archive')
    with plt.rc_context(): main()
