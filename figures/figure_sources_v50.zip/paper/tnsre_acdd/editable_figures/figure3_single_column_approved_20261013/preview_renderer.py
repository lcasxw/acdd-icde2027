"""Finalize the compact oblique ridgelines with symmetric panels and caption-led definitions."""
from __future__ import annotations
import csv
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
PAPER = OUT.parents[1]
ROOT = PAPER.parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle
import numpy as np
import pypdfium2 as pdfium

STEM = 'figure3_single_column'
W, H = 86.8, 128.0
XMIN, XMAX = -18.0, 28.0
LEFT, SPAN, SKEW = 6.5, 65.0, 10.0
DEPTHS = (0.0, 6.7, 15.2, 21.9, 30.4, 37.1)
BASELINES = (76.0, 16.5)
TITLES = (123.0, 63.5)
ZSCALE, ZMAX = 22.0, .32
CI_OFFSET, DOT_DIAMETER = 0.0, .55
MODELS = ('eegnet', 'eeg_conformer')
MODEL_LABELS = ('EEGNet', 'EEG-Conformer')
COHORTS = {
    'discovery': {'label': 'Discovery', 'n': 224, 'fill': '#B7D9E8', 'line': '#5E91A8', 'summary': '#3F748B'},
    'dreyer_confirmation': {'label': 'Dreyer', 'n': 87, 'fill': '#F2E2B5', 'line': '#A18A42', 'summary': '#7C682F'},
    'external_confirmation': {'label': 'Stieger', 'n': 62, 'fill': '#F3A6A6', 'line': '#B96268', 'summary': '#9D4651'},
}
LAYERS = (
    ('discovery', 'prior_quantile_full', 'Full-batch'),
    ('discovery', 'prior_quantile_prefix10', 'Prefix-10'),
    ('dreyer_confirmation', 'prior_quantile_full', 'Full-batch'),
    ('dreyer_confirmation', 'prior_quantile_prefix10', 'Prefix-10'),
    ('external_confirmation', 'prefix10_suffix', 'Prefix→suffix'),
    ('external_confirmation', 'prequential', 'Strict-past'),
)
INK, MUTED, GRID, ZERO = '#29333D', '#66717A', '#E1E6E9', '#A8B3BB'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def rows(p):
    with p.open(encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))
def csvout(name, data):
    with (OUT / name).open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0])); writer.writeheader(); writer.writerows(data)

def main():
    # Snapshot before exporting; all publication assets and scientific tables are protected.
    guard = OUT / 'protected_before.json'
    if not guard.exists():
        protected = [p for folder in ('source_data', 'figures') for p in (PAPER / folder).glob('*') if p.is_file()]
        protected += [PAPER / n for n in ('main.tex', 'main.pdf', 'supplementary.tex', 'supplementary_standalone.pdf',
                       'claim_registry.json', 'source_data_contract.json', 'submission_checks.md')]
        protected += list((PAPER / 'plot_data/figure2_ridges').glob('*.csv'))
        protected += [PAPER / 'plot_data/figure2_ridges/plot_config.json']
        dump('protected_before.json', {p.relative_to(ROOT).as_posix(): sha(p) for p in protected if p.exists()})
    inputs = [PAPER / 'plot_data/figure2_ridges' / n for n in ('participant_long.csv', 'group_summary.csv', 'plot_config.json')]
    inputs += [PAPER / 'source_data/figure2_cross_cohort_forest.csv']
    dump('source_sha256.json', {p.relative_to(ROOT).as_posix(): sha(p) for p in inputs})
    records = rows(inputs[0]); summaries = rows(inputs[-1])
    refs = {(r['phase'], r['backbone'], r['endpoint']): r for r in summaries}
    grid = np.linspace(XMIN, XMAX, 801)
    computed = {}; estimates = []; density_rows = []; observations = []
    for mi, model in enumerate(MODELS):
        for li, (phase, endpoint, label) in enumerate(LAYERS):
            ref = refs[phase, model, endpoint]
            block = [r for r in records if (r['phase'], r['backbone'], r['endpoint']) == (phase, model, endpoint)]
            values = np.array([float(r['gain_pp']) for r in block])
            assert len(values) == len({r['participant_id'] for r in block}) == COHORTS[phase]['n']
            mean, lo, hi = [100 * float(ref[k]) for k in ('mean_gain', 'ci95_lower', 'ci95_upper')]
            assert abs(values.mean() - mean) < 1e-11
            assert XMIN < values.min() <= values.max() < XMAX
            bandwidth = values.std(ddof=1) * len(values) ** (-.2)
            density = np.exp(-.5 * ((grid[:, None] - values[None, :]) / bandwidth) ** 2).mean(axis=1) / (bandwidth * np.sqrt(2 * np.pi))
            assert density.max() < ZMAX
            uid = f'{mi}_{li}'
            computed[mi, li] = values, mean, lo, hi, density
            estimates.append({'id': uid, 'model': model, 'phase': phase, 'endpoint': endpoint, 'n': len(values),
                              'mean_pp': mean, 'ci_lower_pp': lo, 'ci_upper_pp': hi, 'scott_bandwidth_pp': bandwidth,
                              'maximum_density_per_pp': float(density.max()), 'visible_kde_mass': float(np.trapezoid(density, grid))})
            density_rows.extend({'id': uid, 'gain_pp': float(x), 'density_per_pp': float(y)} for x, y in zip(grid, density))
            observations.extend({'id': uid, 'participant_id': r['participant_id'], 'gain_pp': float(r['gain_pp'])} for r in block)
    assert len(observations) == 1492
    csvout('displayed_estimates.csv', estimates); csvout('density_values.csv', density_rows); csvout('participant_values.csv', observations)

    plt.style.use(OUT / 'ccfa_paper.mplstyle')
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'pdf.fonttype': 42,
        'svg.fonttype': 'none', 'svg.hashsalt': 'figure3-final-20261012', 'path.simplify': False,
        'savefig.bbox': None, 'savefig.pad_inches': 0})
    fig = plt.figure(figsize=(W / 25.4, H / 25.4))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set(xlim=(0, W), ylim=(0, H)); ax.axis('off')
    texts = []; geometry = []; density_geometry = []; intervals = []
    def txt(x, y, s, size=7.5, color=INK, ha='left', weight='normal', gid=None, **kw):
        t = ax.text(x, y, s, fontsize=size, color=color, ha=ha, va='center', fontweight=weight, clip_on=False, **kw)
        if gid: t.set_gid(gid)
        texts.append(t); return t
    def seg(a, b, gid=None, **kw):
        p = ax.plot([a[0], b[0]], [a[1], b[1]], clip_on=False, solid_capstyle='round', **kw)[0]
        if gid: p.set_gid(gid)
        return p
    # Shared density and mean/CI definitions are stated in the accompanying caption.
    # No extra scale/key is attached to just one model or cohort.

    for mi, model in enumerate(MODELS):
        base = BASELINES[mi]
        def project(x, depth, z=0):
            return LEFT + (np.asarray(x) - XMIN) / (XMAX - XMIN) * SPAN + SKEW * depth / DEPTHS[-1], base + depth + ZSCALE * np.asarray(z)
        txt(2.5, TITLES[mi], f'({chr(97 + mi)}) {MODEL_LABELS[mi]}', size=9.2, weight='bold', gid=f'panel_title_{mi}')
        # Unfilled, light edge guides retain the categorical oblique structure.
        for side,x in (('left',XMIN),('right',XMAX)):
            seg(project(x,0),project(x,DEPTHS[-1]),gid=f'depth_edge_{side}_{mi}',color='#DEE4E8',lw=.28,zorder=0)
        seg(project(0,0),project(0,DEPTHS[-1]),color='#B7C0C6',lw=.45,linestyle=(0,(2.3,2.3)),zorder=1)
        for li in reversed(range(6)):
            phase, endpoint, label = LAYERS[li]; cohort = COHORTS[phase]; depth = DEPTHS[li]
            values, mean, lo, hi, density = computed[mi, li]; uid = f'{mi}_{li}'
            px, py = project(grid, depth, density); b = base + depth
            zorder = 10 + (5 - li) * 2
            fill = Polygon([project(XMIN, depth), *zip(px, py), project(XMAX, depth)],
                           closed=True, facecolor=cohort['fill'], edgecolor='none', alpha=.85, zorder=zorder)
            fill.set_gid('density_fill_' + uid); ax.add_patch(fill)
            curve = ax.plot(px, py, color=cohort['line'], lw=.55, alpha=.9, clip_on=False, zorder=zorder + .1)[0]
            curve.set_gid('density_curve_' + uid)
            seg(project(XMIN, depth), project(XMAX, depth), gid='baseline_' + uid,
                color='#C2CCD2', lw=.33, zorder=zorder + .2)
            # Mean and interval belong to the ridge floor, with explicit caps and a small dot.
            cx, _ = project(mean, depth); lx, _ = project(lo, depth); hx, _ = project(hi, depth)
            cy = b + CI_OFFSET
            seg((lx, cy), (hx, cy), gid='ci_' + uid, color=cohort['summary'], lw=.8, zorder=40)
            for pos, name in ((lx, 'lo'), (hx, 'hi')):
                seg((pos, cy - .3), (pos, cy + .3), gid=f'cap_{name}_{uid}', color=cohort['summary'], lw=.4, zorder=40)
            dot = Circle((cx, cy), DOT_DIAMETER / 2, facecolor=cohort['summary'], edgecolor='none', clip_on=False, zorder=41)
            dot.set_gid('mean_' + uid); ax.add_patch(dot)
            zero_x, _ = project(0, depth)
            seg((zero_x, b - .65), (zero_x, b + .55), gid='zero_' + uid, color='#8D9BA5', lw=.55, zorder=39)
            # Single-line labels occupy the existing right-tail air; no independent table column.
            end_x, _ = project(XMAX, depth)
            mean_text = txt(end_x + .1, b + 2.25, f'{mean:+.2f}', color=INK, ha='right', gid='estimate_' + uid)
            mean_width_mm = mean_text.get_window_extent(fig.canvas.get_renderer()).width / fig.dpi * 25.4
            txt(end_x + .1 - mean_width_mm - 1.8, b + 2.25, label, color=MUTED, ha='right', gid='endpoint_' + uid)
            if li % 2 == 1:
                start_x, _ = project(XMIN, depth)
                cohort_text = txt(start_x + .7, b + 3.8, cohort['label'], weight='normal', color=INK, gid='cohort_' + uid)
                name_width_mm = cohort_text.get_window_extent(fig.canvas.get_renderer()).width / fig.dpi * 25.4
                txt(start_x + .7 + name_width_mm + 1.5, b + 3.8, f"n={cohort['n']}", color=MUTED, gid='sample_size_' + uid)
                low = project(XMIN, DEPTHS[li-1]); high = project(XMIN, depth)
                seg((low[0]-1.1,low[1]),(high[0]-1.1,high[1]),gid='group_bracket_'+uid,color='#BAC3C9',lw=.4,zorder=35)
                for arm,(xx,yy) in enumerate((low,high)):
                    seg((xx-1.1,yy),(xx-.35,yy),gid=f'group_arm_{uid}_{arm}',color='#BAC3C9',lw=.4,zorder=35)
            geometry.append({'id': uid, 'baseline_y_mm': b, 'depth_mm': depth, 'x_offset_mm': SKEW * depth / DEPTHS[-1],
                'mean_x_mm': float(cx), 'ci_lower_x_mm': float(lx), 'ci_upper_x_mm': float(hx), 'ci_y_mm': cy,
                'ci_length_mm': float(hx-lx), 'mean_diameter_mm': DOT_DIAMETER, 'participant_count': len(values),
                'gain_min_pp': float(values.min()), 'gain_max_pp': float(values.max())})
            density_geometry.append((uid, np.asarray(px), np.asarray(py), b))
            intervals.append((uid, float(lx), float(hx), cy))
        for x in (-10, 0, 10, 20):
            px, py = project(x, 0)
            seg((px, py), (px, py-.7), color=ZERO, lw=.45, zorder=42)
            txt(px, base-3.2, str(x).replace('-', '−'), color=MUTED, ha='center')
        if mi == 1:
            txt(LEFT+SPAN/2, base-7.7, 'BA gain (pp)', size=8, ha='center', gid='shared_gain_title')

    fig.canvas.draw(); renderer = fig.canvas.get_renderer()
    boxes = []; outside = []; collisions = []; text_density = []; text_zero_proximity = []
    for t in texts:
        bbox = t.get_window_extent(renderer)
        boxes.append((t, bbox))
        if bbox.x0 < -.1 or bbox.y0 < -.1 or bbox.x1 > fig.bbox.width+.1 or bbox.y1 > fig.bbox.height+.1: outside.append(t.get_text())
        x0,y0,x1,y1 = (*ax.transData.inverted().transform((bbox.x0,bbox.y0)), *ax.transData.inverted().transform((bbox.x1,bbox.y1)))
        for panel_base in BASELINES:
            ya,yb=max(y0,panel_base),min(y1,panel_base+DEPTHS[-1])
            if ya<=yb:
                zx0=LEFT-XMIN/(XMAX-XMIN)*SPAN+SKEW*(ya-panel_base)/DEPTHS[-1]
                zx1=LEFT-XMIN/(XMAX-XMIN)*SPAN+SKEW*(yb-panel_base)/DEPTHS[-1]
                clearance=max(zx0-x1,x0-zx1)
                if clearance<.5:text_zero_proximity.append({'text':t.get_text(),'clearance_mm':float(clearance)})
        for uid, px, py, floor in density_geometry:
            mask=(px >= x0-.15) & (px <= x1+.15)
            if mask.any() and y1 > floor and y0 < float(py[mask].max()) + .15:
                text_density.append([t.get_text(), uid])
    for i,(t,a) in enumerate(boxes):
        for u,b in boxes[i+1:]:
            if min(a.x1,b.x1)-max(a.x0,b.x0) > .1 and min(a.y1,b.y1)-max(a.y0,b.y0) > .1: collisions.append([t.get_text(),u.get_text()])
    ci_density = []
    for uid,lo,hi,cy in intervals:
        for other,px,py,floor in density_geometry:
            if uid == other: continue
            mask=(px>=lo-.4)&(px<=hi+.4)
            if mask.any() and cy+.4>floor and cy-.4<float(py[mask].max()): ci_density.append([uid,other])
    qa={'minimum_font_pt':min(t.get_fontsize() for t in texts),'text_outside_canvas':outside,'text_collisions':collisions,
        'text_density_collisions':text_density,'interval_density_collisions':ci_density,
        'text_zero_line_proximity':text_zero_proximity,'text_count':len(texts)}
    dump('layout_diagnostics.json',qa)
    assert not any((outside,collisions,text_density,ci_density,text_zero_proximity)),qa
    now=datetime(2026,10,12,tzinfo=timezone.utc)
    fig.savefig(OUT/f'{STEM}.pdf',metadata={'Title':'Cross-cohort participant-gain distributions','CreationDate':now,'ModDate':now})
    fig.savefig(OUT/f'{STEM}.svg',metadata={'Title':'Cross-cohort participant-gain distributions','Date':'2026-10-12'})
    fig.savefig(OUT/f'{STEM}.png',dpi=600,facecolor='white')
    plt.close(fig)
    pdf=pdfium.PdfDocument(str(OUT/f'{STEM}.pdf'))
    for dpi,name in ((240,'pdf_render.png'),(150,'single_column_150dpi.png')):
        img=pdf[0].render(scale=dpi/72).to_pil().convert('RGB'); img.save(OUT/name)
        if dpi==150: img.convert('L').save(OUT/'single_column_150dpi_grayscale.png')
    pdf.close()
    dump('artist_geometry.json',geometry)
    dump('plot_config.json',{'size_mm':[W,H],'x_range_pp':[XMIN,XMAX],'plot_left_mm':LEFT,'plot_width_mm':SPAN,
        'maximum_depth_shift_mm':SKEW,'depths_mm':DEPTHS,'baseline_mm':BASELINES,'density_range':[0,ZMAX],
        'density_scale_mm_per_inverse_pp':ZSCALE,'cohort_colors':COHORTS,'ci_offset_mm':CI_OFFSET,'mean_diameter_mm':DOT_DIAMETER,
        'rug_displayed':False,'all_observations_retained_in_kde':True,'exact_intervals_in_source_csv':True,
        'density_axis_displayed':False,'summary_key_displayed':False,'definitions_in_caption':True,
        'density_scale_applies_to':'all curves in both panels','floor_fill_displayed':False,
        'depth_edge_color':'#DEE4E8','depth_edge_linewidth_pt':.28,
        'cohort_label_weight':'normal','sample_size_gap_mm':1.5,
        'panel_title_y_mm':TITLES,'group_bracket_color':'#BAC3C9','group_bracket_linewidth_pt':.4,
        'endpoint_text_color':MUTED,'mean_text_color':INK,'gain_title_count':1})
    caption="Participant-level balanced-accuracy gains (percentage points) from prior-quantile decisions (declared class prior 0.5) versus default decisions within each endpoint. Dots and bars on each baseline show means and original 95% CIs, respectively; adjacent numbers show means (full intervals: Supplementary Table S17). Gaussian Scott KDEs use all aggregated participant values, shared gain/density scales, and no peak normalization. Density (inverse pp) describes distributions, not mean uncertainty. Read gains from each layer's projected zero (dashed reference); depth is categorical. n counts participants reused across models and endpoints. Discovery CIs use dataset–protocol–participant hierarchical bootstrap; Dreyer and Stieger CIs resample participants after source/seed aggregation. Historical discovery evidence is probability-only. Full-batch is transductive; historical Prefix-10 differs from protected prefix-10-to-suffix evaluation (Prefix→suffix), fitted on ten unlabeled scores and evaluated only on the suffix. Strict-past uses all preceding scores; both Stieger endpoints evaluate trials 11 onward. No cross-access ranking is implied.\n"
    (OUT/'caption.txt').write_text(caption,encoding='utf-8')
    protected=json.loads(guard.read_text(encoding='utf-8'))
    changed=[p for p,h in protected.items() if sha(ROOT/p)!=h]
    assert not changed,changed
    dump('protection_check.json',{'files_checked':len(protected),'changed_files':changed})
    dump('palette.json',{k:v['fill'] for k,v in COHORTS.items()})
    dump('manifest.json',{'chart_type':'author-selected oblique ridgeline distributions','x_categories_ordered':False,
        'additive':False,'uncertainty_present':True,'uncertainty_label':'Original 95% CIs; discovery hierarchical bootstrap; Dreyer/Stieger participant bootstrap',
        'statistical_unit':'participant after frozen within-participant averaging','paired_data':True,'pairing_preserved':True,
        'legend_count':0,'panel_count':2,'series_count':12,'minimum_font_pt':7.5,'final_width_in':W/25.4,
        'export_formats':['pdf','svg','png'],'raster_dpi':600,'color_redundancy':True,'final_size_checked':False,
        'notes':'Preview only. User retains shallow 3D style. Shared density and mean/CI definitions are in the caption. Original observations all remain in KDE and CSV. No paired inference.'})
    dump('design_request.json',{'title':'Single-column cross-cohort distributions, refined','intent':'Retain shallow oblique ridges; make density and uncertainty distinct.',
        'data_structure':{'statistical_unit':'participant','distribution':True,'uncertainty':True,'paired':True,'series_count':12},
        'constraints':{'width_inches':W/25.4,'minimum_font_pt':7.5,'preserve_values':True,'no_table':True}})
    print(json.dumps({'output':str(OUT),**qa},ensure_ascii=False))

if __name__=='__main__': main()
